<div class="table-responsive">
            <table border="1" class="table table-striped">
              <thead>
                <tr>
                  <th>#</th>
                  <th>Firstname</th>
                  <th>Lastname</th>                
                  <th>Father </th>
                  <th>Mother</th>                  
                  <th>district</th>
                  <th>sector</th>                  
                  <th>District</th>
                  <th>Parish</th>
                  <th>lochurch</th>
                  <th>Telephone</th>
                  <th>Photo</th>
                 
                </tr>
              </thead>
              <tbody>
              <?php
                include('../connection.php');
                $Result=mysqli_query( $conn,"SELECT * FROM christians;");

                  while($row=mysqli_fetch_array($Result))
                  {
                    echo '
                        <tr>
                          <td>'.$row["cid"].'</td><td>'.$row["fname"].'</td>
                          <td>'.$row["lname"].'</td><td>'.$row["fath"].'</td>
                          <td>'.$row["moth"].'</td>
                          <td>'.$row["dist"].'</td>'.'</td>
                          <td>'.$row["sect"].'</td><td>'.$row["distr"].'</td>
                          <td>'.$row["parish"].'</td><td>'.$row["lochurch"].'</td>
                          <td>'.$row["tel"].'</td>
                          <td><img style="width:60px;height:60px" class="img-responsive" src="../img/'.$row["photo"].'"
                          <td><p><a href="Editable2.php? id='.$row['cid'].'" class="btn btn-primary">Edit</button><a href="deletechr.php?del='.$row["cid"].'" class="btn btn-danger">Delete</a></p></th></tr>';
                  }
                ?>
               
              </tbody>
            </table>
          </div>