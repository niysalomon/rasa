-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Oct 12, 2017 at 10:26 AM
-- Server version: 5.5.8
-- PHP Version: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `eardb`
--

-- --------------------------------------------------------

--
-- Table structure for table `about`
--

CREATE TABLE IF NOT EXISTS `about` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `amateka` text NOT NULL,
  `date` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `about`
--

INSERT INTO `about` (`id`, `amateka`, `date`) VALUES
(1, 'No my knees and pray', '2016-10-20 12:08:24'),
(2, 'We now need to consider the relationship between data rate and signal rate (bit rate\r\nand baud rate). This relationship, of course, depends on the value of r. It also depends\r\non the data pattern. If we have a data pattern of all 1s or all Os, the signal rate may be\r\ndifferent from a data pattern of alternating Os and Is. To derive a formula for the relationship,\r\nwe need to define three cases: the worst, best, and average. The worst case is\r\nwhen we need the maximum signal rate; the best case is when we need the minimum.\r\nIn data communications, we are usually interested in the average case.', '2016-10-20 12:29:10'),
(3, 'We now need to consider the relationship between data rate and signal rate (bit rate\r\nand baud rate). This relationship, of course, depends on the value of r. It also depends\r\non the data pattern. If we have a data pattern of all 1s or all Os, the signal rate may be\r\ndifferent from a data pattern of alternating Os and Is. To derive a formula for the relationship,\r\nwe need to define three cases: the worst, best, and average. The worst case is\r\nwhen we need the maximum signal rate; the best case is when we need the minimum.\r\nIn data communications, we are usually interested in the average case.\r\n<ul>\r\n<li>Jyewe</li>\r\n<li>Nawe</li>\r\n</ul>', '2016-10-20 12:32:28'),
(4, 'Click clack', '2016-10-20 13:24:00');

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `level` varchar(50) NOT NULL,
  `username` varchar(12) NOT NULL,
  `password` varchar(12) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `level`, `username`, `password`) VALUES
(5, 'Main Admin', 'salo', 'niyo'),
(6, 'Other admin', 'peti', 'peti');

-- --------------------------------------------------------

--
-- Table structure for table `bfiles`
--

CREATE TABLE IF NOT EXISTS `bfiles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `file` text NOT NULL,
  `Name` text NOT NULL,
  `date` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `bfiles`
--

INSERT INTO `bfiles` (`id`, `file`, `Name`, `date`) VALUES
(1, 'img/CameraZOOM-20161020103431542.jpg', 'exm', '2017-07-18 09:16:09'),
(2, 'img/CameraZOOM-20161020103431542.jpg', 'exm', '2017-07-18 09:17:21');

-- --------------------------------------------------------

--
-- Table structure for table `christians`
--

CREATE TABLE IF NOT EXISTS `christians` (
  `cid` int(255) NOT NULL AUTO_INCREMENT,
  `fname` varchar(255) NOT NULL,
  `lname` varchar(255) NOT NULL,
  `gender` varchar(255) NOT NULL,
  `bdat` text NOT NULL,
  `fath` varchar(255) NOT NULL,
  `moth` varchar(555) NOT NULL,
  `prov` varchar(255) NOT NULL,
  `dist` varchar(255) NOT NULL,
  `sect` varchar(255) NOT NULL,
  `cell` varchar(255) NOT NULL,
  `distr` varchar(255) NOT NULL,
  `parish` varchar(255) NOT NULL,
  `lochurch` varchar(255) DEFAULT NULL,
  `tel` text,
  `photo` text,
  PRIMARY KEY (`cid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `christians`
--

INSERT INTO `christians` (`cid`, `fname`, `lname`, `gender`, `bdat`, `fath`, `moth`, `prov`, `dist`, `sect`, `cell`, `distr`, `parish`, `lochurch`, `tel`, `photo`) VALUES
(1, 'niyigira', 'salomon', 'Female', '2222222222', 'erwer', 'ewrewe', 'SOUTHERN', 'Ruhango', 'eretet', 'ertetr', 'Ruhango', 'kinyana', 'retertr', '0782396251', '1029-sankara.jpg'),
(2, 'kalou', 'salomon', 'Female', '2222222222', 'erwer', 'ewrewe', 'SOUTHERN', 'Nyanza', 'eretet', 'ertetr', 'Muhura', 'Nyagatare', 'retertr', '0782396251', '3c5db5a12c5529d464d80bee47b028d3.jpg'),
(3, 'masengesh', 'patrick', 'Female', '2000/01/01', 'mugabo', 'maria', 'NOTHERN', 'Byumba', 'byumba', 'gisuna', 'Byumba', 'Ruhango', 'kinihira', '0786626534', 'Xrstl 20161215_202835.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `communication`
--

CREATE TABLE IF NOT EXISTS `communication` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `resume` text NOT NULL,
  `comm` text NOT NULL,
  `dates` text NOT NULL,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `communication`
--

INSERT INTO `communication` (`id`, `resume`, `comm`, `dates`, `name`) VALUES
(1, 'gfhjgfhjgfjugfjgf', 'fjgfjjgfjgfjgfjgfj', '14/08/2017', 'salomon'),
(2, 'jksdgfusdaftasfr', 'aegftrgftrgftrgftrsufhjefr', '14/08/2017', 'ingoma');

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE IF NOT EXISTS `contact` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(50) NOT NULL,
  `phone` int(10) NOT NULL,
  `email` text NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `contact`
--

INSERT INTO `contact` (`Id`, `title`, `phone`, `email`) VALUES
(5, 'admin', 782396251, 'niysalomon@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `dfile`
--

CREATE TABLE IF NOT EXISTS `dfile` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `file` text NOT NULL,
  `Name` text NOT NULL,
  `date` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `dfile`
--

INSERT INTO `dfile` (`id`, `file`, `Name`, `date`) VALUES
(1, 'img/CameraZOOM-20161102180344222.jpg', 'exam', '2017-07-18 09:14:06');

-- --------------------------------------------------------

--
-- Table structure for table `districts`
--

CREATE TABLE IF NOT EXISTS `districts` (
  `Did` int(15) NOT NULL AUTO_INCREMENT,
  `Dname` varchar(30) NOT NULL,
  PRIMARY KEY (`Did`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `districts`
--

INSERT INTO `districts` (`Did`, `Dname`) VALUES
(1, 'Muhura');

-- --------------------------------------------------------

--
-- Table structure for table `file`
--

CREATE TABLE IF NOT EXISTS `file` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `file` text NOT NULL,
  `Name` text NOT NULL,
  `date` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `file`
--

INSERT INTO `file` (`id`, `file`, `Name`, `date`) VALUES
(1, 'img/CameraZOOM-20161020103434778.jpg', 'akadoc', '2017-07-18 08:57:09');

-- --------------------------------------------------------

--
-- Table structure for table `gallery`
--

CREATE TABLE IF NOT EXISTS `gallery` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(50) NOT NULL,
  `photo` text NOT NULL,
  `Name` text NOT NULL,
  `choir` varchar(50) NOT NULL,
  `date` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=29 ;

--
-- Dumping data for table `gallery`
--

INSERT INTO `gallery` (`id`, `title`, `photo`, `Name`, `choir`, `date`) VALUES
(1, 'kwishima', 'img/DSC_0478.JPG', 'DSC_0478.JPG', 'mothers', '0000-00-00 00:00:00'),
(2, 'yubile sebration', 'img/abayobozi.JPG', 'abayobozi.JPG', 'leaders', '0000-00-00 00:00:00'),
(3, 'crowning', 'img/DSC05697.JPG', 'DSC05697.JPG', 'bishops', '0000-00-00 00:00:00'),
(4, 'Inama ya synode', 'img/DSC_1563.JPG', 'DSC_1563.JPG', 'abitabiriye', '0000-00-00 00:00:00'),
(6, 'Amarushanwa ya korali muri 2015', 'img/gallry (12).JPG', 'gallry (12).JPG', 'korali zi', '0000-00-00 00:00:00'),
(8, 'Gusangira umunsi mukuru na Bishop', 'img/gallry (4).JPG', 'gallry (4).JPG', 'abakristo', '0000-00-00 00:00:00'),
(9, 'ear byumba ya kera', 'img/gallry (9).JPG', 'gallry (9).JPG', 'abakristo', '0000-00-00 00:00:00'),
(10, 'Abana babapastori', 'img/gallry (29).jpg', 'gallry (29).jpg', '', '0000-00-00 00:00:00'),
(11, 'Cathederal St Paul nshya', 'img/cathed.JPG', 'cathed.JPG', 'church', '0000-00-00 00:00:00'),
(12, 'new building', 'img/aubex.JPG', 'aubex.JPG', 'church', '0000-00-00 00:00:00'),
(13, 'photo', 'img/DSC_0478.JPG', 'DSC_0478.JPG', 'MU and FU', '0000-00-00 00:00:00'),
(14, 'yubile sebration', 'img/ear.JPG', 'ear.JPG', 'yubilee', '0000-00-00 00:00:00'),
(15, 'kwishima', 'img/earbyumba (19).JPG', 'earbyumba (19).JPG', 'church', '0000-00-00 00:00:00'),
(16, 'kuririmba', 'img/earbyumba (1).JPG', 'earbyumba (1).JPG', 'church', '0000-00-00 00:00:00'),
(17, 'kuririmba', 'img/Bishop Rwaje Onesphore (3).JPG', 'Bishop Rwaje Onesphore (3).JPG', 'christians', '0000-00-00 00:00:00'),
(18, 'kuririmba', 'img/earbyumba (20).JPG', 'earbyumba (20).JPG', 'christians', '0000-00-00 00:00:00'),
(19, 'kuririmba', 'img/earbyumba (12).JPG', 'earbyumba (12).JPG', 'church', '0000-00-00 00:00:00'),
(20, 'bishops', 'img/Bishop Rwaje Onesphore (1).JPG', 'Bishop Rwaje Onesphore (1).JPG', 'church', '0000-00-00 00:00:00'),
(21, 'yubile sebration', 'img/earbyumba (38).JPG', 'earbyumba (38).JPG', 'yubilee', '0000-00-00 00:00:00'),
(22, 'bishops', 'img/earbyumba (37).JPG', 'earbyumba (37).JPG', 'yubilee', '0000-00-00 00:00:00'),
(23, 'Gutaha inzu ya Ear Byumba', 'img/_DSC0466.JPG', '_DSC0466.JPG', 'ear', '0000-00-00 00:00:00'),
(24, 'Gutaha inzu ya Ear Byumba', 'img/house.JPG', 'house.JPG', 'ear', '0000-00-00 00:00:00'),
(25, 'Gutaha inzu ya Ear Byumba', 'img/inyubako1.JPG', 'inyubako1.JPG', 'yubilee', '0000-00-00 00:00:00'),
(26, 'Gutaha inzu ya Ear Byumba', 'img/INYUBAKO.JPG', 'INYUBAKO.JPG', 'yubilee', '0000-00-00 00:00:00'),
(27, 'Gutaha inzu ya Ear Byumba', 'img/mumugi.JPG', 'mumugi.JPG', 'yubilee', '0000-00-00 00:00:00'),
(28, 'kubaka', 'img/4ab56813gw1dw02vfpcuxj.jpg', '4ab56813gw1dw02vfpcuxj.jpg', 'ear', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `localchurch`
--

CREATE TABLE IF NOT EXISTS `localchurch` (
  `loid` int(11) NOT NULL AUTO_INCREMENT,
  `pid` int(11) DEFAULT NULL,
  PRIMARY KEY (`loid`),
  KEY `pid` (`pid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `localchurch`
--


-- --------------------------------------------------------

--
-- Table structure for table `message`
--

CREATE TABLE IF NOT EXISTS `message` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Name` varchar(40) NOT NULL,
  `Email` varchar(40) NOT NULL,
  `Subject` varchar(40) NOT NULL,
  `Message` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `message`
--


-- --------------------------------------------------------

--
-- Table structure for table `news`
--

CREATE TABLE IF NOT EXISTS `news` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `Title` text NOT NULL,
  `Resume` text NOT NULL,
  `Image` text NOT NULL,
  `Name` text NOT NULL,
  `Content` text NOT NULL,
  `date` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=20 ;

--
-- Dumping data for table `news`
--

INSERT INTO `news` (`id`, `Title`, `Resume`, `Image`, `Name`, `Content`, `date`) VALUES
(1, 'Inama ya Synode', 'Raporo ya Distriki ya Ngarama muri 2016', 'img/audiance.JPG', 'audiance.JPG', ' IMIRIMO Yâ€™UBUYOBOZI:\r\n\r\nHatanzwe icyate cya Diyosezi kugera kuri%\r\nHatanzwe imisanzu ya Yubile ya Diyosezi ingana na:\r\nAbakristo bashyizwe ku igaburo Ryera  \r\nInama z''Itorero zarakozwe\r\nAbakozi barahembwe\r\nIngendo zitandukanye zarakozwe \r\nHigishijwe abigisha urwandiko rwa II & III\r\nAmahugurwa yâ€™abakristo mu byiciro bitandukanye\r\nHaguzwe ibikoresho byo mu biro( par example: computer ya district)\r\n\r\nIVUGABUTUMWA:\r\nHasuwe abakirisito mu ngo  3600\r\nHabatijwe abantu 1.376\r\nHakomejwe abakristo 556\r\nGusurana kw''abayobozi b''Itorero mu maparuwasi agize District\r\nIbiterane mpemburo 9 \r\nIbitaramo by''Ivugabutumwa 27\r\nIbiterane by''abanyamasengesho mu maparuwasi 9\r\nAmarushanwa y''amakorari 27\r\nHinjijwe abanyamuryango 80 muri M.Union\r\nHinjijwe abanyamuryango 292 muri  F.U\r\nHasezeranye imiryango 65\r\nIvugabutumwa mubigo by''Itorero (amashuri ) na Gereza\r\nHatanzwe inyigisho za BEE\r\nHashyizweho inzego z''ubuyobozi mu byiciro by''abakristo\r\nhashinzwe amatorero shingiro mashya 12\r\nHakozwe ibiterane nterankunga 2  kâ€™urwego rwa district na 24 amaparuwasi yakoze  mu rrwego rwo kwishakamo ubushobozi\r\n\r\nHUBATSWE INYUBAKO ZITANDUKANYE:\r\n\r\n-PAROISSE MIMURI / IKANISA YA MAHORO\r\n-INYUBAKO YA EAR PAROISSE MIMURI\r\n-EAR PAROISSE RUTOMA / IKANISA YA RWAGAKARA\r\n-EAR PAROISSE RUTOMA/ IKANISA YA KAJEVUBA.\r\n- EAR PAROISSEMIMURI/ IKANISA YA NYABUGOGO.\r\n- ICUMBI RYâ€™UMUPASITORI/ EAR MIMURI ( IFITE ITERAMBERE RYâ€™UMURIRO WA MOBISOL\r\n- PAROISSE  RUTOMA /IKANISA YA CYABAYAGA\r\n IMIBEREHO MYIZA:\r\nHatanzwe ubwisungane mu kwivuza  ku batishoboye ku miryango  30\r\nHakozwe ubukangurambaga ku kwirinda  imirire mibi mu ngo\r\nHubatswe ubwiherero Kibare, Rutoma na Hunga.\r\nKu nkunga ya EAR D/BYUMBA , hafashwe amazi kurusengero rwa paroisse Hunga(ikigega cya litiro 10.000)\r\nHaguzwe ibikoresho byo mu ngo(matera,intebe, telemosi,amasahani,ibikombe,ameza,ibirangiti,amabati....\r\nHubatswe ishuri ry''incuke muri paroisse Nyamengo; hanashingwa amashuri y''incuke Mimuli, Rutoma na Ngarama.\r\nHateguwe ubusitani hanaterwa ibiti by''imbuto 150  ziribwa Rutoma, Ngarama, Mimuli)\r\nUbukangurambaga ku miturire myiza no kugira isuku.\r\nGufasha no gusura imiryango 10 yahuye n''ingorane cyangwa  yungutse umwana 5\r\nHatanzwe ibikoresho ku banyeshuri 30 biga mu mashuri abanza nâ€™ayisumbuye\r\nTwakiriye abashyitsi batandukanye mu maparoisse yose.\r\nHasuwe abarwayi  27 mu bitaro badafite kirengera\r\nITERAMBERE Mâ€™UBUKUNGU:\r\nHaguzwe ibikorersho byo mu nsengero\r\nHaguzwe  laptop ya district\r\nKubatswe insengero zitandukanye(izizamuye:Mimuli, Rutoma,Rwakayumbu, Kajevuba. Izisakaye: Rwakayumbu, ngarama. Mahoro, gihengeri,Rwagakara.)\r\nHongerewe amatsinda yo kubitsa no kugurizanya 15\r\nHakozwe ubukangurambaga ku gutanga  imigabane muri Sacco ya Diocese\r\nHakozwe igiterane cy''impuguke mu ma paruwasi(1)\r\nHorojwe amatungo magufi  (mu bana)n''amaremare(ihene, inka, inkoko\r\nHatanzwe ibuye ry''ifatizo kuri katederale nshya ya EAR D /BYUMBA\r\nHubatswe kandi hakomezwa kubakwa amacumbi y''abakozi b''Itorero muri paroisse Nyagihanga na Kibare\r\nHaguzwe ibyuma bya muzika muri paroisse Hunga, Kibare, Nyamengo,  Mimuli, Gatsibo na Rutoma.\r\nHashyizwe umuriro mu macumbi hifashishijwe mobisol (Mimuli, Nyamengo na Kibare)\r\nHatanzwe imigabane ku nyubako y''ubufatanye b''amaparuwasi 100% cfr icyate\r\nHazitiwe imbago z''Itorero haterwa ibiti 400 (Nyagihanga, Rutoma na Mimuli)\r\nHatewe ibiti 50 byâ€™ikawa muri paroisse Gatsibo\r\nHubatswe igikoni  muri paroisse Gatsibo, Rutoma )\r\nHateguwe ubutaka bwo guhingamo insina za kijyambere 600 (kibare na nyamengo)\r\nHahinzwe ibishyimbo  ,ibigori ahari imirima ya Paruwasi  mu rwego rwo kubyaza umusaruro ubutaka bwa paruwasi', '13/07/2017'),
(2, 'Inama ya Synode', 'Raporoya ya Mukono muri synode 2016', 'img/DSC_1548.JPG', 'DSC_1548.JPG', 'DISTRICT YA MUKONO 2016\r\n\r\n\r\n\r\n\r\nINTRODUCTION.\r\n\r\n\r\nIyi district igizwe nâ€™amaparuwase 7 ariyo:\r\nMukono, Rukizi,Nyabyondo,Buhita,Manyagiro,Bwambi na Ruyange\r\nIkaba ifite ububwiriza 2 aribwo:\r\nRwasa na Mulindi. \r\n\r\n\r\nIMIRIMO YAKOZWE\r\n\r\n\r\n\r\n\r\nKUBATIZA, habatijwe 717.\r\nGUKOMEZWA 454\r\nGUSHYINGIRA 83\r\nMOTHERâ€™S UNION 64\r\nFATHERâ€™S UNION 69\r\nAMATURO YOSE NI 37,817,838 FRW.', '13/07/2017'),
(3, 'Cathederal St Paul nshya', 'umushinga w''igiceri cy''ijana(100) mukubaka cathederal nshya', 'img/cathed.JPG', 'cathed.JPG', 'EAR Diyosezi ya Byumba ni Diyosezi y''itorero Anglikani mu Rwanda muri Province y''u Rwanda (P.E.A.R).\r\nIcyicaro cya EAR Diyosezi ya Byumba giherereye mu ntara y''Amajyaraguru, Akarere  ka Gicumbi umurenge wa Byumba akagali ka Gacurabwenge , umudugudu wa Rubyiniro.\r\nMurwego rwo kugendera kugishyushanyo mbonera cy''umujyi wa Gicumbi ndetse n''iterambere ry''itorero hatekerejwe ko hakubakwa urusengero rujyanye n''igihe mu gihe cy''imyaka itanu(5ans) kuberako uruhari ubu rurashaje kandi ni ruto ugerenije n''imirimo ikorerwa muri cathedrale. Ni muri urwo rwego hatekereje umushinga wiswe ijana  (100).\r\nAmafaranga azajya atangwa buri cyumeru ni ukuvuga umukristo wese wa EAR Byumba akayatanga aho bahurira mu itorero shingiro rye, itorero shingiro rizatanga umusanzu waryo mu ikanisa buri cyumweru, ibi birasaba ko itorero shingiro riba rikora neza ikanisa itange raporo kuri Paruwsi buri byumweru bibiri, Paruwasi itange raporo kuri Distriki buri byumweru bitatu, Distriki itange raporo muri zone buri kwezi, zone itange raporo muri Diyosezi buri kwezi.\r\nKUGIRA NGO BISHOBOKE\r\n-    Umukirisito wese wa EAR Byumba akwiriye kubanza kumva uruhare rwe muri cathedrale nshashya kugeza ku mwana w''ukwezi kumwe.\r\n-    Umukirisito wese wa EAR Byumba amenyekane mu itorero shingiro rye kandi amenyeshwe iyi Gahunda.\r\nTwibuke gutanga kuko gutanga bihesha umugisha kuruta guhabwa\r\n-    Twibuke gusabira umugisha ITURO UTANZE,  UZARIKORESHA n''UMURIMO RIZAKORA.\r\n-    Akanwa k''mukiranutsi kararema rimwe na rimwe dukora ibintu byatugiraho ngaruka tukibaza byinshi.\r\n-    Urugero: reka tuyatange babone yo bazarya ubwo wibuke ko waryaturiyeho ko rizaribwa.\r\n-    Mureke dufashe pastor natera imbere usange uzavuga ubusa kandi aribyo wasabye\r\n-    Niba ushaka ko twubaka urusengero uvuge uti, iri turo rizatwubakire urusengero kandi ruzuzure vuba.\r\n-    Erega ibyo dufite byose bikomoka ku Mana .\r\n-    Twe gutanga twiganyira twibuka ibyabaye kuri Kayini.\r\nAbakristo 80,000 umusanzu 100 bizaba habazwe ibyumweru 4 mu kwezi bizaba 32,000,000 muguhe kingana numwaka 384,000,000 imyaka itanu ni 1,920,000,000 habazwe ibyumweru bigize umkwaka ni 52 bizaba 2,080,000,000\r\n\r\n', '13/07/2017'),
(4, 'Ijambo rya prezida w''impuguke mu giterane cy''Impuguke 2016', 'Ijambo rya prezida w''impuguke ', 'img/DSC0222.JPG', 'DSC0222.JPG', 'IGITERANE CY''IMPUGUKE ZA EAR/DIOCESE YA BYUMBA: KUWA 17/09/2016 \r\nInama yatangiye saa yine n''igice (10:30) iyobowe n''Umwepisikopi wa EAR Diyosezi ya Byumba, ikaba yatangijwe n''isengesho twayobowemo  na Rev. Pasteur Principal wa District ya Mukono. Twakomeje turirimba indirimbo ya 22 mu ndirimbo z'' agakiza.\r\nIBIRI KU MURONGO W''IBYIGWA\r\n1. Kwakira perezida w''impuguke\r\n2. Choir Rangurura\r\n3. Ikiganiro cy''umutumirwa w''uyu munsi\r\n4. Indirimbo\r\n5. Kuganirira mu matsinda\r\n6. Guhuza ibyavuyemo\r\n7. Raporo zo muri za Districts zose\r\n8. Umudendezo\r\n9. Gusoza \r\n10. Ubusabane\r\nINDAMBURANGINGO Y''INAMA\r\nIJAMBO RYA PEREZIDA W''IMPUGUKE\r\nPerezida   w''impuguke mbere yo kugira icyo avuga yabanje gushimira Nyakubahwa umwepisikopi  watekereje ko iyi iyi kipe y''impuguke yabaho anakomeza  asobanurira abitabiriye   ibirebana n''impuguke za EAR D Byumba aho yasobanuye ko icyi ari igikorwa ngarukamwa kikaba gikozwe ku shuro ya 5. Yaboneye no  gusobanura ko mu nama iherutse hari imishinga  itatu yari ku isonga kandi yashyizwe mu bikorwa: ishuri rya King Salomon Academy, Sacco Ihumure ya EAR D/Byumba na Fondation UWAMALIYA Victoire. \r\nKu birebana na  KSA(King Salomon Academy), hasobanuwe ko hamaze kubakwa ibyumba birindwi, bitatu byuzuye na 4 bitaruzura. Ku birebana  na SACCO, impuguke zirakangurirwa gukomeza gutanga umusanzu wa 3000frws. Hanasobanuwe ko kugira ngo umuntu abe umunyamuryango wa Fondation UWAMALIYA Victoire, umusanzu ungana n''ibihumbi icumi(10.000).\r\nPerezida w''impuguke yaboneyeho kuvuga  ko impuguke zikora ari ko hakaba haboneka imbogamizi zitari nyinshi: Guseta ibirenge kuri bamwe, kuba nta bureau ihari  bityo uburyo bwo gukoreramo bukaba butoroshye( informal system). Perezida  w''impuguke mu gusoza ijambo rye yasabye impuguke ko tugomba gukorera hamwe kugira ngo tugere ku ntego twiyemeje.\r\n', '14/07/2017'),
(5, 'Ijambo rya Bishop mu giterane cy''Impuguke za Diocese', 'Ijambo rya Bishop mu giterane cy''Impuguke za Diocese 17/09/2016', 'img/DSC0175.JPG', 'DSC0175.JPG', 'Nyakubahwa Bishop mu ijambo rye, yatangiye ashimira abitabiriye igiterane cy''impuguke ku nshuro  ya 5, bakubiye mu byiciro bitandukanye: amakomisiyo atandukanye, abapasitori bayobora za Districts zigize EAR D/BYUMBA, abayobozi ba za zone ebyiri, abapasitori  hamwe n''abandi bahyitsi basangwa n''abatumirwa  baturutse hanze ya DIOCESE. Intego y''ijambo : Kugenda nk''uko bikwiriye ab''Umwami wacu (guhamya umwami wacu Yesu Kirisito)  aho yari ikubiye mu byanditswe dusanga muri Bible (abakorosayi:1:9-11;ibyakozwe n''intumwa:1:7-11;ibyahishuwe :2;12-17.Umwepisicopi yasobanuye ko aho gukorera harahari ahubwo nuko hatasabwe kandi yemereye inama ko  nihabaho ubushake harara  habonetse kandi impuguke zikabazidakora mu buryo buri informel kubera ko Sinode icyo yemeje kiba kibaye  itegeko mu  itorero Angicane . Umwepisicopi yagejeje ku bitabiriye inama  bimwe  mu bikorwa byagezweho mu myaka 25 ishize:\r\n-  Kubaka isengero\r\n-  Kongera umubare wa FU, na M.U\r\n-  Kubaka inzu z''ubucuruzi,\r\n-  Ubuhinzi bwa kijyambere\r\n-  Kwibumbira mu matsinda\r\n-  Fondation UWAMALIYA Victoire\r\n-  Kubaka centres de santÃ© 2\r\n-  Ishuri rya King Salomon Academy\r\n-  Amashuri y''imyuga (VTC)\r\n-  Sacco\r\n\r\nUmwepisicopi yakomeje ageza  ku bitabiriye  inama ibyavuye mu nama yahuje abapasiteri n''abalayiki haganirwa buryo ki umurimo wanozwa hagati y''abapasitori n''abalayiki . Icyagaragaye nuko imikorere ihagaze kuri 70%. Umwanzuro wafatiwemo nuko amakosa yagiye agaragaramo agiye gukosorwa ku buryo mu nama itaha  ibintu bizaba bimeze neza cyane iterambere ari ryose. Impuguke zakomeje zisobanurirwa igishushushanyo cya Cathederale  ya EAR Diyosezi ya BYUMBA aho izubukwa itwaye amafaranga  asa miliyari  eshatu. Hanagaragajwe ibikorwa biteganywa kuzakorwa :\r\n-  Kubaka Cathederale\r\n-  Kubaka amagorofa abiri\r\n- Gukomeza gushishikariza  impuguke  gutanga umusanzu muri SACCO\r\n-  Gukomeza inyubako ya King Salomon Academy\r\nIbi byose bikaba bikorwa bigerwaho ku bufatanye n''impande zose.\r\n\r\n', '14/07/2017'),
(6, 'IJAMBO RYA CANON MFITUMUKIZA SAMUEL', 'Ijambo rya ka Canon MFITUKIZA Samuel mu giterane cy''impuguke', 'img/samuel.JPG', 'samuel.JPG', 'Yatangiye abwira  impuguke ko ari byiza kwihana kubera ko ari byo bifasha  mu kurwanya amakimbirane hagati y''abakozi b''Imana bityo iterambere rikihuta, yifashishije indirimbo ya 198. Iyi ndirimbo ikaba iririmbwa himikwa abapasitori. Canon yasobanuye ko itorero ryubatse ku mashyiga atatu nk''uko tubisoma muri Zaburi 144:12 : Abakuru, abana n''urubyiruko byose tukabifashwamo n''Imana. Yakomeje asobanura ko hari ibintu  bigera kuri bine biri guhiga isi dutuyeho:\r\n1. Materialism: (gushaka ubutunzi bw''isi: abakirisito n''abapasitori)\r\n2. Humanism : Ibitekerezo Imana itarimo ( ubwenge bw''isi), ubwenge bwiza ni ubwenge bwa Kirisito, buturuka ku MANA.\r\n3. Environmental : ubutaka abantu babumaze. Gukoreraho ibindi bikorwa nko gutera ibiti, kandi  ibiti bikurura ubutaka kandi tukanatekereza ku birebana n''imbyaro  turwanya inzara kubera ko ntabwo byoroshye kubwiriza ubutumwa umukirisito ushonje.\r\n4. Religious pluralism : ( amatorero ari kugenda aba menshi). Icyo impuguke zihamagarirwa ni uguhamya Yesu Kristo nk''Umwami nk''umukiza.\r\n5.Globalisation: isi iri kugenda iba akarwa gatoya : Inama zitangwa aha ngaha nuko tugomba kwitwara neza ku bintu birebana n''ikoranabunga ( watsap, internet,twitterâ€¦). Ni byiza kubisesengura neza tutitaye ku byo abazungu bandika gusa ahubwo  natwe tugomba kwandika ibyacu.\r\n\r\nCanon yakomeje atanga inama  :\r\n-  Kubaka itiroro rimwe (Unity) kubera ko  muri Kirisito turi umwe kandi umuntu w''Imana ni ukizwa;\r\n-  Paruwasi ikuze ntabwo ari Paruwasi  irwama ahubwo hagomba kubaho gushyira hamwe;\r\n-  Itorero rigomba guhuza abantu bose( nta mukene, nta mukire);\r\n-   Itorero  ryubakiye kuri classes eshatu:\r\n           -  High class( abategetsi, abacuruzi)\r\n           -  Middle class( professionals)\r\n           -   Lower class ( abo hasi)\r\n-  Umuhamagaro nyakuri ni ukuvuga ubutumwa;\r\n-   Kuba impumuro nziza kuri bagenzi bacu bakizwa;\r\n-  Umurimo w''abakirisito ni kubaka itorero  no kuramya Imana;\r\n-  Abakirisito bareberera itorero;\r\n-  Abakirisito bahemba abakozi babo;\r\n-  Gukora nta gihembo: gukorera ijuru gusa;\r\n-  Abakirisito bagomba kurwanirira itorero;\r\n-  Abakirisito bahamagariwe gufasha abatishoboye;\r\n-  Guharanira impinduka ibitari mu buryo tubishyira mu buryo;\r\n-  Abakozi b''Imana beza bafasha abadafite imbaraga ( facilitators);\r\n-  Guhanurira abantu binyuze mu mwuka bitari kurota.\r\n', '14/07/2017'),
(7, 'icyo Impuguke zafasha', 'Ibi byavuzwe mu giterane cy''impuguke za Diocese kuwa 17/09/2016', 'img/impugke.JPG', 'impugke.JPG', 'ICYO IMPUGUKE ZAFASHA\r\n-  Zirashoboye kandi zirasobanukiwe;\r\n-  Kwigishwa bakigisha;\r\n-  Gukora imirimo y''itorero bashinzwe;\r\n-  Gukoreshwa n''abayobozi b''itorero;\r\n-  Kwihana hakabaho kwikorera umusaraba wa Yesu Kirisito;\r\n-  Kwirinda ibizana ibice.\r\nCanon yasoje ijambo rye agaragaza ibizana  kwiremamo ibice anasaba ku birwanya twivuye inyuma kugirango itorero rikomeze gutera imbere: ishyari, ubudashora (gushaka gukora ibyo abandi bakora), kutihana ( kudasabana imbabazi).\r\nUBUTUMWA BWO MURI DIOCESE SHYIRA\r\nIntumwa zaturutse muri Diocese ya Shyira  zagaragaje ko mu rwego rw''uburezi bamaze kugera ku rwego rwo kugira ishuri rya kaminuza (MIPC)  aho byahereye ku kigo cya Sonrise High School. Ubu burezi bukaba buterwamo inkunga n''umushinga w''Abanyamerika bityo bituma banabona amahirwe ya sponsorship ku banyeshuri ndetse na equipments zitandukanye mu muri ibi bigo by''amashuri. Sonrise itanga  Uburezi butegura umunyeshuri gukura mu buryo butatu: gukura mu buryo bw''umubiri, mu mwuka no mu mitekerereze kandi  ikaba yigisha cyane ibijyanye na  ICT Programs. Impamvu yatumye habaho kwitabira iyi nama ni mu buryo bwo gushishikariza abanyeshuri batandukanye kugana iri shuri  kubera ubumenyi buhatangirwa.\r\nNyuma y''ikiganiro cy''abatumirwa babiri,  impuguke zifuje kumenya aho ingufu zaturuste, hasobanuwe ko ubushobozi bwabaturutsemo hamwe no kwiyambaza Bank (inguzanyo). Ibirebana n''imyigishirize  abakozi bakora muri Sonrise ni nabo bigisha muri kaminuza. Discipline yubakiye ku mategeko n''amahame by''itorero. Izi ntumwa zikaba zasabye ko niba hari abapasiteri bashoboye nabo bashobora  gusaba bakajya kwigishamo. Impuguke zifuje ko habaho partnership  hagati ya Diocese yacu n''iya Shyira. Hashimangiwe ko ibi byose  bizakomeza kubakira k''ubufatanye, ubuvugizi  kandi ko uyu mushinga wa Kaminuza mu ndoto ya Diocese  nawo urimo kubera ko Bizana employment ku bantu batandukanye.\r\n\r\nAbashyitsi bifuje kumenya uko twatangije SACCO, basobanuriwe ko  byose byaturutse mu gitekerezo n''intumbero  bya  Nyakubahwa Bishop. Impuguke zimaze kubyumva no kubinonosora  zisaba ko binyuzwa muri Sinode  irabyiga irabyeza. Ubu yaratangiye nyuma y''imyaka itanu yigwaho kandi ubu ifite izina rya: ABIZERANA SACCO EAR BYUMBA ifite compte No: 560-413946210143. Impuguke zagaragarijwe ko no hanze ya Diocese impuguke zihari  kandi zitandukanye mu bihugu bitandukanye: France, Japan na Chine. Impuguke zifuje ko hazakorwa ka depliant kagaragaza indangangagaciro z''impuguke kugira ngo zirusheho gukora.\r\nImpuguke zongeye kwibutswa website ya EAR/D ya Byumba kandi banakangurirwa ko impuguke n''abandi  bakirisito bazajya banyuzaho ibitkerezo: www.ear-byumba.org.\r\n\r\n\r\n\r\nUmunyamakuru NTAMBARA Gallileo ukorera Isango star, yasobanuye ibijyanye n''umushinga wa  Radiyo y''itorero Anglicane hamwe na TV bizatangizwa (15:30) byazafasha itorero mu ivugabutumwa. Aha umukirisito atanze amafaranga 300 ku mwaka  bikaba byakorwa.\r\nMuri iki giterane kandi cy''impuguke habayeho gutangaza umusanzu wabonetse mu cyumweru cyahariwe impuguke mu madisitiriki yose nk''uko bigaragara mu mbonerahamwe ikurikira:\r\nUmuyobozi w''inama yasoje saa cyenda n''igice ashimira abitabiriye anabasaba kugenda uko bikwiriye ab''Umwami wacu.\r\nNyumayaho bagiye kwifata amafoto y''urwibutso\r\n', '14/07/2017'),
(8, 'HMT igaragaza ibyakozwe muri 2016', 'Inama ya synode HMT igaragaza ibyakozwe muri 2016', 'img/DSC_1563.JPG', 'DSC_1563.JPG', 'Hakoreshejwe amafaranga angina na 1,66,1,720frw mu kugaburira abana 37 .\r\nHishyuriwe mutuelle de sante abana 41 ndetse hanavuzwa nabarwaye.\r\nHaguzwe ibikoresho byâ€™abana biga muri primaire na secondaire,Minervale  ndetse na Uniforme zabo.\r\nHari abana bahawe ubujyanama ndetse bamwe basubizwa mu mashuri.\r\nHari abana basuwe mu ngo ndetse banahabwa ubufasha burimo nko korora inkoko harimo nâ€™umwe mu babuze umubyeyi.\r\n\r\n\r\n                            IMBOGAMIZI.\r\n\r\nUbushobozi buracyari buke bwo kwita ku bana turera.\r\n                         IBYIFUZO.\r\nKuba hasubukurwa imwe mu myuga yahagaze ndetse hakaba haboneka nâ€™amasoko.\r\n                                   MURAKOZE.', '2017-07-18 10:55:10'),
(9, 'Inama ya Synode', ' RAPORO  YA SINODE 23-24/11/2016', 'img/bushara.jpg', 'bushara.jpg', 'IMIBEREHO MYIZA Nâ€™UBUKUNGU\r\n1.IKIGO NDERABUZIMA  CYA BUSHARA\r\nIkigo nderabuzima cya Bushara ni ikigo cya EAR D Byumba kibarizwa muri Paruwasi EAR Byushara, Umurenge wa Shangasha. Gitanga service ku bantu 17,040.\r\n\r\nIKIGO NDERABUZIMA CYA  RUHENDA\r\nIkigo nderabuzima cya Ruhenda  gikorera mu mazu ya EAR D Byumba, aho Itorero ryatije  izi nyubako  ubuyobozi bwite bwa Leta- Akarere ka Gicumbi\r\nRero Diyosezi yahakoreye imirimo  itandukanye\r\n\r\nIBYAKOZWE\r\n- Kubaka inyubako  yagenewe abana, Inzu yâ€™abana yashyizwemo ibikoresho byâ€™ababrwayi : Ibitanda 8, Matola 10 nâ€™ibiryamirwa,  Kugura imiti nâ€™ibindi bikoresho byo kwa muganga\r\nGusana inyubako, Kwakira impano ya Moto TF yavuye muri Minisiteri yâ€™Ubuzima, Gushaka umukozi umwe wâ€™umuforomo,  Kugura parava, chariot, igikoresho  gipima diyabeti nâ€™umuvuduko wâ€™amaraso,  Kwagura ubusitani mu kigo, Kugura ibigega 2 byo gufata amazi\r\n                           IMBOGAMIZI\r\n- Ikigo ntigifite imbangukiragutabara, Amazi adahagije, Abaforomo  bake: Aho kuba 15 ivuriri rifite 8\r\n                           IBYIFUZO\r\nGusaba Leta kwihutisha umuriro wâ€™amashanyarazi  kugira ngo haboneke ingufu zizamura amazi ku isoko\r\nKongera  umubare wâ€™abaforomo ku ivuriro\r\nKugira imbangukiragutabara ku ivuriro\r\n\r\nIBIKORWA BYA 2017\r\n\r\n- Imirimo ya â€˜clinicâ€™, Gutanga umusanzu wo kubaka ikaisa ya Munini , Guhunura inyubako zisigwa amarangi, Kugura insenerateur nâ€™ibyobo.', '2017-07-18 11:02:47'),
(10, 'Uburezi', 'ibyagezweho mu burezi', 'img/refectoire.JPG', 'refectoire.JPG', 'Amashuri 2 yâ€™ikitegererezo: GS Muhura, ES Mukono\r\nAmashuri 12 ya gahunda yâ€™uburezi bwâ€™imyaka 9&12\r\nAmashuri abanza 14\r\nIshuri  1 ryigenga ribanza nâ€™incukerya King Salomon Academy\r\nIbigo 2 byâ€™imyuga nâ€™ubumenyi ngiro Kageyo VTC na Rutare VTC\r\nAmashuri yâ€™incuke 21\r\n                        IBYAKOZWE\r\nGushyiraho umuyobozi kuri GS Mabare\r\nGushyiraho abakontabure kuri GS Hunga na GS Rutoma\r\nGuhindura abayobozi ba GS Bisika, GS Bugomba, GS Nyagakizi, GS Bushyanguhe, EP Bugarura, EP Mamfu, EP Muhura.\r\nGukora inama yâ€™uburezi ku rwego rwa Diyosezi zihuza abayobozi bâ€™ibigo nâ€™abapasitori\r\nGukora inama zâ€™uburezi ku rwego rwa Disitiriki zihuza abapasitori nâ€™abayobozi bâ€™ibigo\r\nGukora inama zâ€™ababyeyi nâ€™abarezi\r\nGS MUHURA\r\n\r\nGS MUHURA  ni ishuri ryisumbuye ryâ€™ikitegererezo riherereye muri Paruwasi Muhura\r\nIshuri ubu rifite abanyeshuri 420\r\nGS Muhura ifite icyiciro rusange nâ€™amashami\r\nNi  ishuri ryigisha ubumenyi (Science )\r\nAmashami:\r\nIki kigo  kiza mu bigo bya mbere gitsindisha 95-99% \r\n              \r\n\r\n\r\n\r\nInzu yâ€™abana\r\nibitanda\r\nibigega\r\n  IBYAKOZWE\r\nImyigire nâ€™imyigishirize\r\nImyidagaduro (sport & loisir):\r\nKugaburira abanyeshuri \r\nKwishyura ubwishingizi bwâ€™abanyeshuri\r\nKwambika abanyeshuri impuzangano\r\nImyubako yâ€™ikikoni : kurangiza cheminÃ©e\r\nGusana \r\nKubaka ishuri rizakira ishami rishya\r\nIkiguzi byatwaye 65,040,362\r\nGukorera mu mazu ashaje: inzu yâ€™ubuyobozi irava\r\nKutagira inzu yâ€™isomero (biblotheque)\r\nKutagira ibibuga byo gukiniraho kandi dufite urubyiruko rukeneye gukina.\r\n\r\n                     IBIKORWA BYA 2017\r\nKukomeza kunoza ireme ryâ€™imyigire nâ€™imyigishirize\r\nKugaburira abanyeshuri\r\nKubaka ibyumba 2 byâ€™amashuri\r\nKubaka inzu yâ€™isomero\r\nGutangira kubaka buhorobuhoro  icumbi ryâ€™abahungu.\r\n\r\n IBIKORWA BYA 2017\r\nGushyiraho abashinzwe amasomo kuri GS Hunga, GS Mabale, GS Rukizi, GS Muyumbu,\r\nGutangiza ikigega cyâ€™uburezi\r\nGutangiza icyumweru cyâ€™uburezi\r\nKwizihiza imyaka 500 yâ€™ivugurura ryâ€™abaporotestanti mu mashuri\r\nGukwirakwiza BibiliyaKonera imbaraga mu bukangurambaga  mu babyeyi ku kuzamura ireme ryâ€™uburezi\r\nGukora ibaruramibare mu mashuri\r\nKunoza imikorere nâ€™imikoranire ku rwego rwâ€™ikigo, Paruwasi, na Leta\r\nGukora inama yâ€™uburezi ku rwego rwa Diyosezi zihuza abayobozi bâ€™ibigo nâ€™abapasitori\r\nGukora inama zâ€™uburezi ku rwego rwa Disitiriki zihuza abapasitori nâ€™abayobozi bâ€™ibigo\r\nKubaka King Salomon Academy\r\nGukora ibaruramibare mu mashuri\r\nKunoza imikorere nâ€™imikoranire ku rwego rwâ€™ikigo, Paruwasi, na Leta\r\nGukora inama yâ€™uburezi ku rwego rwa Diyosezi zihuza abayobozi bâ€™ibigo nâ€™abapasitori\r\nGukora inama zâ€™uburezi ku rwego rwa Disitiriki zihuza abapasitori nâ€™abayobozi bâ€™ibigo\r\nKubaka King Salomon Academy\r\nKongera imbaraga hitabwaho ibigo byâ€™imyuga nâ€™ubumenyi ngiro\r\nGutanga impamyabumenyi kuri Kageyo VTC na Rutare VTC\r\nGushaka ubufatanye  hagatati yâ€™Itorero na Leta mu gucunga Kibali VTC', '2017-07-18 11:12:42'),
(11, 'ES Mukono', 'ES Mukono ni ikigo kibarizwa muri Paruwasi Mukono ', 'img/urugendo shuri.JPG', 'urugendo shuri.JPG', 'ES Mukono ni ikigo kibarizwa muri Paruwasi Mukono\r\nNi ikigo cyâ€™ikitegererezo gicumbikira abanyeshuri bâ€™ibitsina  byombi\r\n                    IBYAKOZWE\r\nGuteza imbere imyigire nâ€™imyigishirize\r\nKugaburira abanyeshuri ?\r\nGuhugura abarimu kuri gahunda nshya ( CBC )\r\nGushinga Ishema Club inyuzwamo ibikorwa byâ€™ubumenyi ngiro\r\nKurema amatsinda  agizwe nâ€™abanyeshuri 15 yo kwiga Bibiliya\r\nKwandikira Akarere hasabwa ishami rishya rya Mathematics Computer, Economics\r\nGusana pavoma  yâ€™inzu yâ€™icumbi  nâ€™ubwogero byâ€™abahungu nâ€™inzu abanyeshuri bafatiramo amafunguro.\r\nImikino nâ€™imyidagaduro irimo amarushanwa\r\nIMBOGAMIZI\r\nIshuri rifite ideni rinini ritwara ku ngengo yâ€™imari amafaranga menshi\r\nAmafaranga atangwa na Leta atinda cyane gutangwa\r\nImyumvire nâ€™imikorere bikiri hasi ku bantu bamwe na bamwe barimo abakozi bidindiza iterambere\r\n                         IBIKORWA BYA 2017\r\nKugaburira abanyeshuri\r\nGukomeza guhugura abarimu kuri gahunda nshya (Competence Based Curriculum )\r\nGushaka imfashanyigisho  gahunda nshya\r\nKongera umubare wâ€™abanyeshuri bakava kuri 224 bakagera  nibura kuri 400\r\nGukomeza amatsinda yo kwiga Bibiliya\r\nGusana inyubako (Icumbi ryâ€™abahungu , ubwiherero bwâ€™abarezi, icumbi ryâ€™abarezi,  icumbi ryâ€™umuyobozi no gusiga amarangi\r\nKugura mudasobwa 5\r\nKongera ubworozi ingurube zikava kuri 4 zikagera kuri 10\r\nKuzana umuyoboro wâ€™amazi ya WASAZAC mu kigo', '2017-07-18 11:18:35'),
(12, 'urubyiruko', 'Urubyiruko rwa EAR Diocese Byumba', 'img/_DSC0056.jpg', '_DSC0056.jpg', 'Muri Diyosezi urubyiruko  (imyaka 18-35 ) bangana na 17,148 ku bakirisito 71,745 bagize Diyosezi \r\nUrubyiruko ni icyiciro kinini cyâ€™Itorero ryâ€™uyu munsi nâ€™ejo hazaza\r\nUrubyiruko ni imbaraga zâ€™Itorero\r\nUrubyiruko rugomba kwitabwaho kugirango rwigirire akamaro, rukagirire Itorero nâ€™aho rubarizwa\r\nIMBOGAMIZI\r\nImyumvire yâ€™urubyiruko yâ€™uko Itorero riri ku rwego rwa Diyosezi\r\nKomite zâ€™urubyiruko zidakora  uko bikwiriye\r\nImikoranire hagati ya Pasitori na Komite zâ€™urubyiruko  ntiri ku kigero gishimishije\r\nAmikoro make yo gufasha mu murimo wâ€™urubyiruko\r\nBenshi mu rubyiruko ntibaboneka iyo bahamagawe nâ€™Itorero\r\n IBYAKOZWE\r\nGutora Komite yâ€™urubyiruko ku rwego rwâ€™amakanisa, Paroisse, Disitirki na Diyosezi\r\nIbarura ryâ€™urubyiruko rwose rwa Diyosezi\r\nIbarura ryâ€™urubyiruko rwiga muri za Kaminuza no mu mashuri makuru\r\nIgiterane cyâ€™urubyiruko ku rwego rwa Diyosezi\r\nIgiterane cyâ€™urubyiruko ku rwego rwa Disitiriki Byumba na Muyumbu\r\nIbiterane , imikono,imiganda mu maparuwasi\r\nUrubuga rwa whatsapp ruhuza abanyeshuri ba Kaminuza mu Rwanda no mu mahanga\r\n                     IBYIFUZO\r\nAmahugurwa ku nshingano zâ€™abagize komite\r\nKunoza imikoranire hagati yâ€™abayobozi na komite yâ€™urubyiruko\r\nUrubyiruko bagomba kwitabira  imirimo bakorerwa nâ€™Itorero\r\nGushyiraho umusanzu ufasha kunganira mu imirimo yâ€™urubyiruko\r\n\r\n                       IMISHINGA NA GAHUNDA\r\nDiyosezi ifite imishinga na gahunda bigamije  guteza imbere amajyambere yâ€™icyaro mu mibereho myiza nâ€™ubukungu.\r\nIyi mishinga na gahunda bigamije kubona imibereho yâ€™abaturage bâ€™aho Diyosezi ikorera iruhaho kuba myiza.\r\nSAVING AND CREDIT ASSOCIATION PROGRAM\r\nIyi gahunda EAR D Byumba iyiterwamo inkunga na Hope International\r\nIyi gahunda ni iyo guzigama no kugurizanya bishingiye ku Itorero cyangwa ku Ijambo ryâ€™Imana\r\nMuri Diyosezi dufite amatsinda 1266, arimo abantu 26664\r\n                     IBYAKOZWE\r\nGushinga  amatsinda 102\r\nGutegura ibiterane byo gushima mu Itorero byâ€™amatsinda akorera muri Paruwasi 6 (Muhura, Kibali, Kitazigurwa, Bisika,Rugandu, Kavumu)\r\nKwerekana Film ku bayobozi bâ€™amatsinda 200, abayobozi bâ€™Itorero 60 hamwe nâ€™abanyamatsinda 420\r\nGukora inama 12 zâ€™abafashamyumvire 82\r\nGukora imyiherero 3 yâ€™abafashamyumvire 36\r\nGukora  isuzumabikorwa ryâ€™abafasha-\r\nmyumvire 27\r\nGukangurira amatsinda 500 kwiyandikisha  no kugira umugabane muri SACCO yâ€™Itorero\r\nKwizihiza umunsi mpuzamahanga wo\r\nKuzigama hanakorwa imurikabikorwa ryâ€™ibikorwa byâ€™amatsinda muri Paroisse Kitazigurwa\r\nGutanga udutabo105 twigishirizwamo Ijambo ryâ€™Imana\r\n                        IBYIFUZO\r\nUbuyobozi bwa Paruwasi bugomba kugira iyi Programu iyabo ;\r\nUbuyobozi bwa Paruwasi bugomba gufasha gukurikirana ubuzima bwâ€™amatsinda muri Paruwasi akoreramo.                                      \r\n IBIKORWA  BYA 2017\r\nGukora ubukangurambaga kuri Youth Union mu maparuwasi\r\nGukora ubukangurambaga kuri â€˜â€™ Boysâ€™ and Girls Brigadeâ€™â€™ mu maparuwasi\r\nGutegura amahugurwa  ya komite ku murimo wâ€™Imana mu rubyiruko\r\nGutegura ibiterane byâ€™urubyiruko  ku rwego rwa Paruwasi, Disitiriki na Diyosezi\r\nGutegura amarushanwa y''amakorali ku rwego rwa Paruwasi, Disitiriki na Diyozezi\r\nAmasengesho ku rwego rwa Paruwasi,\r\nDisitiriki na Diyosezi\r\nGuhugura urubyiruko kuri gahunda yo kuzigama no kugurizanya ku rwego rwa Disitiriki\r\nGushyiraho amatsinda yo kubitsa no kugurizanya no guhemba irikora neza cyane ku rwego rwa Disitiriki\r\nGuhuza urubyiruko n''ibigo by''imari  ku rwego rwa Paruwasi\r\nGutegura "Twe Itorero ry''ejo week"\r\nGuhugura urubyiruko ku buzima bw''imyororokere\r\nGukina imikino ya Gicuti\r\nGushyiraho ikipi y''umupira w''amaguru ya District\r\nGushyiraho itorero ry''imbyino\r\nAmarushanwa y''amatorero\r\nAmarushanwa mu mivugo\r\n', '2017-07-18 11:37:46'),
(13, 'Imishinga', 'VSL SCALE UP, SKILLING FOR CHANGE  NA HAND IN HAND CAREA AND JOB CREATION', 'img/busharas.jpg', 'busharas.jpg', 'Muri VSL SCALE UP , EAR D /Byumba iterwamo inkunga na CARE International, ugamije  guhanga ,guhugura no gukurikirana amatsinda yo  kuzigama ,kugurizanya, kugobokana no gushora amafaranga mu mirimo iciriritse ibyara inyungu  no guhuza nâ€™ibigo byâ€™imari ku bantu bakennye mu turere twa Gicumbi, Gatsibo na Nyagatare: Amatsinda  1038 arimo abantu 30060\r\nMuri SKILLING FOR CHANGE,  EAR D/BYUMBA  mu bufatanye na CARE INTERNATIONAL ishyira mubikorwa uyu mushinga  ugamije gufasha abanyarwanda kwivana mubukene, bahanga imirimo itanga akazi ku bandi hibandwa cyane cyane kâ€™ubantu bari mu cyiciro cya 1 na 2 byâ€™ubudehe.\r\nGuhindura abagore ba rwiyemezamirimo\r\nUkorera mu Karere ka Gicumbi imirenge 6.\r\nGuhuza abagenerwabikorwa nâ€™urugaga rwa bagore bikorere mugihugu.\r\nGuhanga imirimo mubagenerwabikorwa ba matsinda mu mushinga\r\nGushishikariza abagenerwabikorwa gutanga akazi kuri iyo mirimo yahanzwe.\r\nKwigisha abagenerwabikorwa guhanga umurimo\r\nGuhugura abagenerwabikorwa ku iterambere rya ba rwiyemezamirimo.\r\nGuhugura abagenarwabikorwa ku mari nâ€™incungamari\r\n\r\n   IMBOGAMIZI\r\nImishinga yashoje ibikorwa  bityo nâ€™inkunga irahagarara\r\nGukurikirana ibikorwa  ntibyoroshye kubera amikoro adahagije\r\n                                IBYIFUZO\r\nGukomeza ubuvugizi  kuko iyi mishinga aho yakoreye yerekanye impiduka abandi bifuza\r\nGukomeza gukorana  no gufatanya nâ€™ubuyobozi bwite bwa Leta  nâ€™abakangurambaga mu gusigasira ibyagezweho\r\nGukora imishinga\r\nMuri HiH & CARE Job creation,  Diocese ikorana nâ€™amatsinda yo kuzigama no kugurizanya 788 yo mu turere twa Nyagatare na Gatsibo tugizwe nâ€™abanyamuryango 22,816. Guhugura amatsina 788\r\n. Guhugura  abanyamuryango  bâ€™amatsinda 22.816\r\nku guhanga  imirimo, Kongera agaciro no gucunga imali\r\n. Guhanga ibikorwa bibyara inyungu 24.381\r\n. Guhanga akazi :33.491\r\n.Kubahuza nâ€™ibigo byâ€™imari\r\n.Guhuza abagore  nâ€™abikorera bâ€™abagore\r\n                  IBYAKOZWE\r\nKuri iyi mishinga yose yashoje imirimo yayo muri 1/2016\r\nGushyikiriza ibikorwa byâ€™imishinga uturere twose\r\nGukora raporo zisoza imishinga\r\nCARE International  yahaye Diyosezi moto 5 zo gukurikirana ibikorwa twasigaranye\r\nInama zâ€™urugaga rwâ€™abakangurambaga ', '2017-07-18 11:56:20'),
(14, 'Gutaha inzu ya Ear Byumba', 'EAR Diyosezi ya Byumba yatashye ku mugaragaro inzu ', 'img/yubilee hous.jpg', 'yubilee hous.jpg', 'EAR Diyosezi ya Byumba yatashye ku mugaragaro inzu iherereye mu mugi wa Gicumbi ahazwi kuri Approvia iyo nyubako ikaba yuzuye itwaye afaranga arenga miliyoni magana atandatu na mirongo itanu(650,000,000Frw)\r\naha ni Bishop Emmanuel NGENDAHAYO ari kumwe na Arch Bishop wa province Dr Onesphore RWAJE ndetse Mayor w''Akarere ka Gicumbi bari gutaha ku mugaragaro iyi nyubako yiswe YUBILEE HOUSE \r\nNyuma yo kuyifungura ku mugaragaro nibwobatangiye gutemberezwa na nyiricyubahiro NDENDAHAYO Emmanuel muriyo nyubako abereka uko imeze  \r\nEAR Byumba ikaba itangaza ko mu rwego rwo kwiteza imbere kwigira kandi no guteza imbere abaturage yatekereje kubaka inzu y''ubucuruzi ijyanye n''igihe mu mugi wa Gicumbi kugirango ifashe abacuruzi gucuruza ibicuruzwa byabo ndetse na EAR Diyosezi ya Byumba nayo ibone amafaranga azajya ayifasha mu bikorwa bitandukanye avuye mu gukodesha iyo nyubako kandi ibyongeyeho igaha ishusho nziza umugi ituyemo\r\n', '2017-07-18 12:11:43'),
(15, 'EAR Byumba irizihiza Yubilee', 'EAR Byumba imaze imyaka makumyabirin n''itanu', 'img/earyubile.jpg', 'earyubile.jpg', 'Kuwa 27/11/2016 mu masaha ya saa yine nibwo umutambagiro warurimo gukorwa muri stade ya Gicumbi aho harimo ingeri ndetse n''amatsinda y''ivugabutumwa menshi atandukanye aho bande ya boys and girls brigade yaririmo igenda ibasusurutsa ku karasisi\r\nNyuma y''iyo myiyereko Nyiricyubahiro Musenyeri Emmanuel NGENDAHAYO yabasabiye umugisha yakarira Arch Bishop Onesphore RWAJE akomeza yakira abandi bari baraho mungeri nyinshi zitandukanye twavuga nk''Abashumba baturutse mu ma diyosezi yose yo mu Rwanda, abari mu kiruhuko cy''izabukuru ndetse n''abandi baturute hanze y''igihugu, n''abandi bakozi b''Imana batandukanye baraho. Mu buyobozi bwa leta aho hari hari Governor w''intara y''Amajyaruguru, intumwa yo munteko ishingamategeko, Mayor w''Akarere ka Gicumbi ndetse n''abamwungirije, abashinzwe umutekano bakuru ndetse nabandi \r\n\r\nNyuma yaho Nyiricyubahiro Musenyeri wa Diyosezi ya Byumba yarahije abapatori ba Diyosezi ya Byumba anabasengera abasabira imbaraga zo kuzababashisha gusohoza inshingano zabo kandi anakomerezaho ashima kandi anahemba imiryango yitwayeneza kandi ifite umwihariko ko nayo imaze imyaka 25 ibana aboneraho no guha umwanya Bishop Nathan GASATURA kugirango abasengere anabasabira umugisha.\r\nNyuma y''aho nibwo bahise bacinya akadiho mbere yo kwakira umuvugabutumwa\r\n', '2017-07-18 12:30:35'),
(16, 'Ijambo rya Bishop wa EAR Byumba', 'Ijambo rya Bishop Emmanuel NGENDAHAYO', 'img/bishop''s speech.jpg', 'bishop''s speech.jpg', 'avuga ko Imana yaduhaye ariyo gushima kuko yaduhaye abayobozi beza ab''itorero ndetse n''igihugu kuko ubuyobozi bwiza butuma n''amatorero asenga neza afite umutekano kandi ashimira n''arch Bishop kuko ar''impano Imana yahaye abanyabyumba mu myaka igera kuri cumi n''icyenda n''umuryango kandi ibikorwa yahasize babifashe nk''umusingi barimo gukomerezaho kandi ko urimo kwera imbuto kandi nabo bategura ibyo bazaha abazabakurikira kandi ko uwavuga ibyakozwe atabirangiza ariko bimwe muribyo:\r\nMu ivugabutumwa: ko bari bafite Abapasiteri cumi nabatandatu(16) ariko ubu bakaba ari mirongo itandatu na batatu(63) kandi bari mungeri z''amashuri zitandukanye kandi amakanisa maganabiri na mirongo irindwi(270) none ubu magana atatu na mirongo itandatu nane(364) kandi no kubaka abantu mumitima biciye muri gahunda ya SOCIOTHERAPY kandi no mubuzima bafashije 23000 kubashakira aho kuba babaha amabati ndetse n''amahema, bashyizeho ibigo nderabuzima bibiri bitanga serivise mu mirenge ibiri Byumba na Bushara ndetse no gutanga uburere bagarura abana kumenya basekuru ba nyirakuru banyirasenge ndetse nabandi bakishima kandi m''ubuzima n''imibereho myiza mu isuku n''amazi  bahaye imiryango  irenga 17000 amazi aturuka kubigega nahandi.\r\n\r\nMu burezi twari dufite amashuri 16 none ubu yabaye31 ndetse n''amarerero ndetse n''ay''incuke, kubonera abana ibyangombwa barenga 709 ndetse no gufasha abacikanywe n''amashuri barenga21360\r\nmu iterambere mu bworozi batanze inka 800 ingurube 600 ihene 1370 mu buhinzi bahaye imiryango irenga 220 ubushobozi bwo kwishakiraibibatunga no gusagurira amasoko kandi no guhangana nihindagurika ry''ikirere bashyiraho imashini zuhira no gufasha abaturage kubona ubushobozi faranga bababumbira mu matsinda aho ubu abaturage barenga 51462 bashyizwe mu matsinda yo kubitsa no kugurizanya amafaranga yabaciye mu maboko akaba ari 800,000,000Frw\r\nkandi bubatse amazu atandukanye yo gufasha abacumbitsi abagenzi ndetse nabacuruzi nk''nzu yatashywe ifite agaciro k''amafaranga arenga 650,000,000Frw kandi no gushyira urubyiruko mu matsinda aho kugirango rwangare mu mihanda ndetse n''abashesha kanguhe kandi ntago bemeranya nabavuga ngo urukwavu rukuze bararurya ahubwo rukomeza kubungabungwa nizo rwonkeje.\r\n\r\nKandi akomeza avuga ko intego y''uyu mwaka tuyisanga mu balewi "25:13 aho batubwira ngo muri uwo mwaka wa yubile mujye musubira kuri gakondo"kuko ishusho dufite ariyo itwereka iyo tuzagira kandi tukava mubyiza tukajya mubindi kuko twaremewe ibyiza gusa ntabindi twaremewe kuko ashima Imana kuko ibyo byose ariyo yabikoze ikatwemerera guhurira hano kandi arangiza ashimira abantu batandukanye byumwihariko abakristo ndetse na leta n''indi miryango itangukanye igenda ibafasha muri gahunda zitandukanye harimo n''impuguke za Byumba ziba hanze ya Byumba kandi ashimira Imana kubw''imyaka 25 kuko ari kimwe cya kane cy''ikinyejana kandi asoza agira ati tuzirikane ko turi agakaramu kari muntoki z''uwahanze isi n''ijuru kandi ashaka kutwandikisha iby''urukundo kugirango isi yose imenye iby''urukundo rwayo kandi no mugihe kizaza tuzabone ubugingo bw''iteka tukiri tuhakure ibyiringiro by''uyu munsi n''ejo hazaza mu izina rya Data n''iry''Umwana ''Umwuka wera Amana.\r\n', '27/11/2016'),
(17, 'Yubilee', 'Ijambo rya Nyiricyubahiro Musenyeri Onesphore Rwaje', 'img/archbishop''s speech.jpg', 'archbishop''s speech.jpg', ' Nyiricyubahiro Musenyeri Onesphore Rwaje yahawe ijambo abanza gushimira abaraho, akomeza abwira abaraho aho diyosezi yavuye ko yavuye ahakomeye guhera muri 1991 aho hari hari umutekano mucye mu gihugu ariko ko atacitse intege aho yari avuye no mumahanga atamenyereye u Rwanda ariko ko atacitse intege afatanyije nabo yarahasanze n''ubwo bari bacye dore ko yakoranaga n''abapasiteri batarenze marindwi(7) muri diyosezi yose dore ko yakoraga akora nka coach capitain naho uwari umunyamabanga wa diyosezi ari nawe Musenyeri uriho ubu we akaba captain bakoze byinshi bitandukanye kandi bubaka diyosezi kugera aho igeze ubu kandi anashimira cyane abanyabyumba kuko babaremye kandi bagafata abana nkababo kandi anavuga uko bafashanyaga n''andi matorero bagafasha abatishoboye bagafatanya kubantu bari bafite kandi no kubintu byose bari bafite kandi arangiza abashimira kandi ababwira gukomeza bakaba ba captain naba coach captain.', '2017-07-18 12:56:57'),
(18, 'Yubilee y''imyaka 25 ear Byumba imaze', 'Ijambo rya Guverineri w''intara y''Amajyaruguru', 'img/govnor.jpg', 'govnor.jpg', 'Nyuma yaho yasabye  Meya guha ikaze guverineri w''intara y''Amajyaruguru ndetse ari nawe wari umushyitsi mukuru\r\nGuverineri yatangiye abashimira kuba bamutumiye kandi anabagezaho intashyo zitandukanye harimo iza President wa Repubulika y''u Rwanda ndetse na Minisitre w''ubutegetsi utabashije kuhaboneka kubw''impamvu zamutunguye kandi akomeza avugako inshingano za musenyeri zidatandukanye n''inshingano z''umuyobozi w''intara kandi ko ko abagomba kubifatanyamo\r\nbakita k''ubaturage dore ko ntamizinga ivuga mu gihugu kuko igihugu gifite umutekano kandi dore ko Musenyeri cyangwa se na Pasiteri adakenera kujya mu karere ava mukandi ngo akenere VISA ahubwo agenda kandi kumutekano kandi no miyindi myaka makumyabiri n''itanu itaha batera intambwe iruta cyane iyo bateye kubufatanye. Kandi ashimira itorero ku bwabyinshi ikorera abaturage harimo kubaha amshuri amavuriro ndetse n''ibindi kandi ashimira gahunda ya mfasha nkufashe cyangwa mvura nkuvure(SOCIOTHERAPY) kandi akomeza shimira itorero kuko rigira uruhari rukomeye mu guteza imbere umugi muri gahunda zitandukanye, kandi avugako Krito bakiriye bamwakira bari mu mutekano kandi nta bitekerezo bibi bafite kandi ko Umwuka wera utura mu rugo rufite isuku\r\nisabukuru itubwira ko igihugu cyacu gifite umutekano kuko kumara iyo myaka yose aricyo bivuka bakagira imitekerereze myiza kandi bakubaka itorero rishingiye k''urubyiruko kuko arirwo torero ry''ejo hazaza\r\nkandi ashishikariza n''andi matorero ko yagira ubufatanye kandi soza abashishikariza gukomeza gutwaza kugirango imibereho yacu kandi yanyu ikomeze kugirango ukwemera kwabo gushinge imizi.\r\n', '2017-07-18 13:00:53'),
(19, 'igitera', 'cyate', 'img/_B240147.JPG', '_B240147.JPG', 'ghfghgf', '2017-09-09 09:02:10');

-- --------------------------------------------------------

--
-- Table structure for table `newspics`
--

CREATE TABLE IF NOT EXISTS `newspics` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `title` text NOT NULL,
  `photo` text NOT NULL,
  `Name` text NOT NULL,
  `content` text NOT NULL,
  `date` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `newspics`
--

INSERT INTO `newspics` (`id`, `title`, `photo`, `Name`, `content`, `date`) VALUES
(1, ' Inama ya Synode', 'img/Imp4.jpg', 'Imp4.jpg', '', '14/08/2017'),
(2, ' Inama ya Synode', 'img/Imp4.jpg', 'Imp4.jpg', 'abantu bitabiriye inama ya synode', '14/08/2017'),
(6, 'Cathederal St Paul nshya', 'img/Cathedera st Paul.jpg', 'Cathedera st Paul.jpg', 'inyubako', '14/08/2017');

-- --------------------------------------------------------

--
-- Table structure for table `parishs`
--

CREATE TABLE IF NOT EXISTS `parishs` (
  `pid` int(11) NOT NULL AUTO_INCREMENT,
  `pname` varchar(255) DEFAULT NULL,
  `Did` int(11) DEFAULT NULL,
  PRIMARY KEY (`pid`),
  KEY `Did` (`Did`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `parishs`
--


-- --------------------------------------------------------

--
-- Table structure for table `postall`
--

CREATE TABLE IF NOT EXISTS `postall` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `paragraph` text NOT NULL,
  `photo` text NOT NULL,
  `image` text NOT NULL,
  `dates` text NOT NULL,
  `fields` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=30 ;

--
-- Dumping data for table `postall`
--

INSERT INTO `postall` (`id`, `paragraph`, `photo`, `image`, `dates`, `fields`) VALUES
(1, 'Boys and girls brigade in EAR Byumba Diocese\r\nBoys and girls brigade is a Christian disciplined and uniformed group that helps youth to become followers of our lord Jesus Christ with an aim of extending Christians kingdom among the youth, the group helps them to  have a sense of responsibility through self control and find true enrichment in life.\r\nIts mandate is to mould the children into wholesome characters mentally, physically and spiritually. The children are taught how to be independent in other words to see an opportunity and to seize it. They are trained in a military fashion in order to give them the military discipline in carrying out the duties and responsibilities bestowed upon them.\r\nbrigade covering the same age group also aims at promotion of habits of obedience, reverence, discipline, self respect and all that tends towards a true Christian manliness\r\nThe boys and girls brigade through various activities gives the children an opportunity to develop mind, body and spirit in preparation for a life of useful Christian service and witness. This is through their Saturday meetings at the church compound at 3:00pm.\r\nCollectively it tends to shape the children in four aspects namely spiritual, education, social and physical aspects. We strongly believe in yielding young individuals who will be strengthened to face any challenges of their present days', 'gallry (10).JPG', 'img/gallry (10).JPG', '13/07/2017', 'bgbrigade'),
(2, 'Duties and responsabilities of Boys and Girls Brigade\r\ni)    Training\r\nIn order to mould the boys and girls to the levels required, the trainers are initially trained in various aspects of handling of the youth in a military style that invokes discipline.\r\nii)   Promotion of Missionary work\r\nThe young people are also taught in a manner to mould them spiritually through seminars and retreats\r\niv)    Social Economic Requirements\r\nAs the group is trained in a military style it is noted that it would be difficult to include the physically challenged, but plans are underway to see how they can be addressed.\r\nv)   Information Communication Technology\r\nThis is an area that is being addressed as it would be unwise to to be left behind in the current technological advancement', 'DSC_4937.JPG', 'img/DSC_4937.JPG', '13/07/2017', 'bgbrigade'),
(3, 'Mission Beliefs:\r\nWe are the choice for disciplined youth\r\nWe provide fun, meaningful with our changing world. and challenging activities\r\nWe teach, preach Christianity, and live it.\r\nWe are committed to serve the community.\r\nWe are enterprising, in tune\r\nWe engage our stockholders\r\nWe are for promotion of education, relief of poverty, and protection of childrenâ€™s rights.\r\nWe are served and led by the volunteers.', 'DSC_3106.JPG', 'img/DSC_3106.JPG', '13/07/2017', 'bgbrigade'),
(4, 'Food security livestock: 600 beneficiaries received through associations 600 cows and 2000 beneficiaries received 2000 goats, Cows artificial insemination and 52 hectors were prepared where, 308,153 trees for consumable fruit, erosion protection, animals feeding were planted. \r\nIGP(Income Generating Program) and management of associations and cooperatives, 600 people have received agricultural support of different seeds like 18610 kilos of Irish potatoes, 2260 mushroom, cabbage, carrots, and onions;', 'Amashirahamwe  (3).JPG', 'img/Amashirahamwe  (3).JPG', '13/07/2017', 'agriculture'),
(5, 'a lot of areas used to exploit through in agriculture', 'Ubuhinzi  (1).JPG', 'img/Ubuhinzi  (1).JPG', '13/07/2017', 'agriculture'),
(6, 'this is muhura parish', 'Muhura  (1).JPG', 'img/Muhura  (1).JPG', '13/07/2017', 'muhura'),
(7, 'we praise the Lord through in singing', 'DSC07388.JPG', 'img/DSC07388.JPG', '13/07/2017', 'choir'),
(8, 'mvura nkuvure progra', 'Socioterapy.JPG', 'img/Socioterapy.JPG', '13/07/2017', 'sociotherapy'),
(9, 'Elites of Church in Ear Byumba Diocese', '_DSC0179.JPG', 'img/_DSC0179.JPG', '13/07/2017', 'elites'),
(10, 'youth union make different activities', 'gallry (11).jpg', 'img/gallry (11).jpg', '13/07/2017', 'youth'),
(11, 'Ear Byumba Diocese start in 1991', 'hist.JPG', 'img/hist.JPG', '13/07/2017', 'aboutus'),
(12, 'Cathederal Saint Paul Byumba', 'eglise.JPG', 'img/eglise.JPG', '13/07/2017', 'byumba'),
(13, 'this is Muyumbo District', 'Paruwasi Muyumbu.JPG', 'img/Paruwasi Muyumbu.JPG', '13/07/2017', 'muyumbo'),
(14, 'Rukizi Parish in Mukono District', 'Paruwasi Rukizi.JPG', 'img/Paruwasi Rukizi.JPG', '13/07/2017', 'mukono'),
(15, 'Pastor in Rutare District', 'rutare (3).jpg', 'img/rutare (3).jpg', '13/07/2017', 'rutare'),
(16, 'Kigarama is on of This', 'allparish.jpg', 'img/allparish.jpg', '13/07/2017', 'kigarama'),
(17, 'Ngarama is one of this', 'allparish.jpg', 'img/allparish.jpg', '13/07/2017', 'ngarama'),
(18, 'Korozanya programs', 'Korozanya Compassion.JPG', 'img/Korozanya Compassion.JPG', '13/07/2017', 'livestock'),
(19, 'saving groups in Ear Byumba', 'IMG_3860.JPG', 'img/IMG_3860.JPG', '13/07/2017', 'savings'),
(20, 'care to children by feeding them and giving them what they want', 'Caps.PNG', 'img/Caps.PNG', '13/07/2017', 'hannah'),
(21, 'we spread water in different areas', 'amazi.JPG', 'img/amazi.JPG', '13/07/2017', 'health'),
(22, 'this is kibali program that help Diocese in different areas', 'run (1).JPG', 'img/run (1).JPG', '13/07/2017', 'run'),
(23, 'Friend of Byumba that give different helps', 'IMG_0104.JPG', 'img/IMG_0104.JPG', '13/07/2017', 'friends'),
(24, 'Mothers''Union is an anglican female christians organisation that has objectives of making families that depends on christ.\r\nNow Mother''s Union has 3200 members, it works in all 42parishs and 4 sub-parishs that are in Ear Byumba. Mothers''Union has 45 branchs all together. \r\n\r\n\r\nM.U has 5 Objectives which are the following:\r\n1. to get mariage with thier partners and to encourage other families.\r\n2. to care children for getting grown conneted christ\r\n3. increasing unit of christians through in praying,song for God and other activities characterise christianity\r\n4. to protect peoples''behaviours and to fight against any thing that can make families to be chaked, and get developed.\r\n5. To help and support the families that are in riskzones.', 'gallry (23).JPG', 'img/gallry (23).JPG', '14/07/2017', 'mothersunion'),
(25, 'Hannah Ministry, an autonomous organisation within the Anglican diocese of Byumba in Northern Rwanda, wishes to encourage individuals, churches, business groups, grant-making trusts and other specialty organizations to commit to three year sponsorships of child-headed orphan families. The sponsorship will be administered by the UK charity, Friends of Byumba Trust , set up to encourage such humanitarian initiatives within the Byumba area.\r\nSponsorship programs\r\nHannah Ministry has identified and is already providing a modicum of support to about 200 child-led orphan family units in the Byumba area.\r\n12 family units have received sponsorship resulting from spontaneous initiatives from individual foreign donors. In some sense these sponsorships have been a pilot programme, enabling the team to develop and refine the sponsorship proposal which it now wishes to make available to the rest of the families by making a concerted effort to find additional sponsors.', 'hnnah (1).JPG', 'img/hnnah (1).JPG', '18/07/2017', 'hannah'),
(26, 'The Hannah Ministry programmes aim to achieve the following by the provision of practical support:\r\n- Empower the oldest child to take responsibility for his or her brothers and sisters to create a child-led family unit.\r\n- Counseling and personal and group therapy (with other family unit leaders)\r\n- Regular coaching and support in planning for the needs of the unit.\r\n- Provision of vocational training designed to the skills and aptitude of each family leader.\r\n-Provide basic needs to the family unit.\r\n- Basic food needs.\r\n- Clothing.\r\n- Accommodation (often providing a roof, windows and doors on walls built by the children and their neighbours).\r\n- Social insurance to cover sickness and health needs.\r\n- Manpower to create and work on garden plots to grow foodstuffs making a large contribution towards achieving self-sufficiency in food.\r\n- Release the pressure on the family unit of treatment of children infected with HIV/AIDS\r\n- Free provision of nourishing meals in the central Hannah Ministry facility in order to strengthen the body to enable effective drug treatment.\r\n', 'FUV1.jpg', 'img/FUV1.jpg', '18/07/2017', 'hannah'),
(27, 'The sponsorship package, to which Hannah Ministry asks each sponsor to commit is as follows. Sponsorship can either be individual, or as a group, so long as all members of the group commits to it:\r\n\r\n- A pledge of Â£20 per month over three years to be paid by Standing Order into the Friends of Byumba Trust. (The three year pledged commitment is important, so that the recipient family does not feel rejected by frequent changes in stand-in parents)\r\n-  UK tax-paying sponsors are encouraged to make their pledges by Gift Aid. Funds derived from covenant tax recovery received by Friends of Byumba Trust will be used to support the Hannah Ministry team, infrastructure and operating costs in Byumba. All the pledged sums will be used to support the needs of the child-led families. (However, since the precise needs of family units will vary, the actual use of the funds to each family will be at the discretion of the Hannah Ministry staff)\r\n-  Provision by the sponsor of photographs and a brief resume (in the format provided) of the sponsor and its members.\r\n-  Each 6 months, the sponsor will receive an updated photo, together with letter (with translation) from the members of the family unit, together with a short report on progress, issues, challenges from a Hannah Ministry staff member.\r\n- Every year, each sponsor will receive a summary copy of the Hannah Ministry Annual. Report, highlighting issues, progress and financial situation of the ministry as a whole\r\n-  Sponsors are encouraged to correspond and send updated photos as they wish, and the staff undertake to make such material readily available to the children.\r\n- Six months before the end of the three year sponsorship period, Hannah Ministry will supply the sponsor with an assessment of the state of self-sufficiency of the family, together with an assessment of the need for any further sponsorship, and at what level (without any obligation on the sponsor to continue with sponsorship support).\r\n\r\n', 'hannah.jpg', 'img/hannah.jpg', '18/07/2017', 'hannah'),
(28, 'THE ORIGINS OF ORGANISATION.\r\nUWAMARIYA Victoire was born on 26/07/1978, and passed away on 08/05/2015.\r\n\r\nIn her life time she was characterized by the love of God and those that He created:\r\n- She has achieved a lot in the Anglican Church of Rwanda Byumba Diocese , in the community and in the area of evangelism:\r\n- She strived for the development of girls and women for she was even the President of Mothers Union in the Diocese.\r\n- She fought against the Child violence in school and in the families through FVA.\r\n- he helped many orphans and single mothers through HANAH Ministry.\r\n- She worked hard to protect and help the needy people.\r\n- In the area of health she was the chair person of the Board of Byumba Hospital and a chair person of the social commission at Gicumbi District.\r\n- She made a research on the life of the elderly people and on how they can be supported in their last days.\r\nIn Education she started a model school:King Salomon Academy\r\n\r\nGENERAL OBJECTIVES OF  ORGANISATION\r\nIn memory of the late of Victoire Uwamariya, the main objective of this organisation  is to promote the wellbeing of the people need, especially those in situations that they are unable to overcome for themselves.\r\nSPECIFIC OBJECTIVES OF THE ORGANISATION\r\n-To help the children in need through education and other areas of life.\r\n-To help the women in their own and family development.\r\n-To contribute to the fight for the children''s rights.\r\n-To support the nursery Education.\r\n-To care for the needy in general.\r\n   CHARACTERISTICS OF THE ORGANISATION\r\n-The  Uwamariya Victoire Organisation will work in the same way as all other NGOs and Non Profit organizations, it will be governed by the same law that governs these organization.\r\n-The Headquarters of an organisation will be in Gicumbi District and can be transferred to another area or have branches according to the growth of the foundation\r\n- Uwamariya Victoire Organisation is a Christian Organization. \r\n\r\n', 'vicky.JPG', 'img/vicky.JPG', '21/07/2017', 'ouv'),
(29, 'THE MEMBERS OF THE ORGANOSATION.\r\n- Individual people who would like to continue the work of Victoire Uwamariya,\r\n- Associations and Organizations that would like to promote the wellbeing of the people (moral Person)\r\n\r\nVISION OF THE ORGANISATION\r\nThe Vision of this Foundation comes from Victoireâ€™s idea where she wanted to see people equipped holistically.\r\nMISSION OF THE ORGANISATION\r\nThe Mission of this Foundation is to work for the peopleâ€™s development, wellbeing, culture and religious, in order to enable people have people built holistically.\r\n', 'UVF.JPG', 'img/UVF.JPG', '21/07/2017', 'ouv');

-- --------------------------------------------------------

--
-- Table structure for table `programs`
--

CREATE TABLE IF NOT EXISTS `programs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Title` varchar(40) NOT NULL,
  `Paragraph` text NOT NULL,
  `date` datetime NOT NULL,
  `Day` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `programs`
--

INSERT INTO `programs` (`id`, `Title`, `Paragraph`, `date`, `Day`) VALUES
(1, '', '', '0000-00-00 00:00:00', ''),
(2, '', '', '0000-00-00 00:00:00', ''),
(3, 'fweert', 'er,date', '2017-08-12 14:18:11', 'Saturday');

-- --------------------------------------------------------

--
-- Table structure for table `property`
--

CREATE TABLE IF NOT EXISTS `property` (
  `propid` int(11) NOT NULL,
  `propname` varchar(35) NOT NULL,
  `location` varchar(30) NOT NULL,
  `values` int(20) DEFAULT NULL,
  `user` varchar(30) NOT NULL,
  `comment` text
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `property`
--


-- --------------------------------------------------------

--
-- Table structure for table `pubs`
--

CREATE TABLE IF NOT EXISTS `pubs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(40) NOT NULL,
  `image` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `pubs`
--

INSERT INTO `pubs` (`id`, `title`, `image`) VALUES
(2, 'KING SALOMON ACADEMY', 'king.gif'),
(5, 'cdfc byumba', 'centre.gif');

-- --------------------------------------------------------

--
-- Table structure for table `report`
--

CREATE TABLE IF NOT EXISTS `report` (
  `rid` int(255) NOT NULL AUTO_INCREMENT,
  `dates` blob NOT NULL,
  `planact` text NOT NULL,
  `doneact` text NOT NULL,
  `nodoneact` text NOT NULL,
  `noplanact` text NOT NULL,
  `prob` text NOT NULL,
  `sugg` text NOT NULL,
  `observ` text NOT NULL,
  `worker` text NOT NULL,
  `post` text NOT NULL,
  `comment` text NOT NULL,
  PRIMARY KEY (`rid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=12 ;

--
-- Dumping data for table `report`
--

INSERT INTO `report` (`rid`, `dates`, `planact`, `doneact`, `nodoneact`, `noplanact`, `prob`, `sugg`, `observ`, `worker`, `post`, `comment`) VALUES
(1, 0x31372f30372f32303137, '', '', '', '', '', '', '', '', '', ''),
(2, 0x31372f30372f32303137, '', '', '', '', '', '', '', '', '', ''),
(3, 0x31372f30372f32303137, 'It has to be something you are sufficiently interested in write 4000 words on, and as the extended essay needs to be in one of the given subject areas, ensure that your ideas clearly fit into this area', 'It has to be something you are sufficiently interested in write 4000 words on, and as the extended essay needs to be in one of the given subject areas, ensure that your ideas clearly fit into this area', 'It has to be something you are sufficiently interested in write 4000 words on, and as the extended essay needs to be in one of the given subject areas, ensure that your ideas clearly fit into this area', 'It has to be something you are sufficiently interested in write 4000 words on, and as the extended essay needs to be in one of the given subject areas, ensure that your ideas clearly fit into this area', 'It has to be something you are sufficiently interested in write 4000 words on, and as the extended essay needs to be in one of the given subject areas, ensure that your ideas clearly fit into this area', 'It has to be something you are sufficiently interested in write 4000 words on, and as the extended essay needs to be in one of the given subject areas, ensure that your ideas clearly fit into this area', 'It has to be something you are sufficiently interested in write 4000 words on, and as the extended essay needs to be in one of the given subject areas, ensure that your ideas clearly fit into this area', 'EWRTWERTWE', 'SETWETWER', 'It has to be something you are sufficiently interested in write 4000 words on, and as the extended essay needs to be in one of the given subject areas, ensure that your ideas clearly fit into this area'),
(4, 0x31372f30372f32303137, '', '', '', '', '', '', '', '', '', ''),
(5, 0x31372f30372f32303137, ' \r\n\r\nNAME: NIYIGIRA SALOMON\r\nREGISTRATION NUMBER: 216237173\r\nSCHOOL OF ICT  \r\nCOMPUTER SCIENCE LEVEL II \r\nENGLISH FOR ACADEMIC PURPOSE \r\n\r\nASSIGNMENT: SUMMARY FOR WRITING EXTENDED ESSAY\r\nExtended Essay: Is a research paper of up to 4,000 words giving students an opportunity to conduct independent research or investigation on a topic that interests them. There are 10 steps to achieving a great extended essay, these are:\r\n1.	Choosing a Topic\r\n2. Brainstorming Ideas\r\n3. Research your topic\r\n4. Organizing the argument structure: Preliminary outline\r\n5. Refine Argument: Extended Outline\r\n6. Consider Evidence\r\n7. Assumptions/ cognitive bias\r\n8. Evaluate\r\n9. Draft Essay\r\n10. Final Essay\r\nâ€¢ Annotated bibliography\r\nâ€¢ Write abstract\r\nStep 1: Choosing a topic.\r\nIt has to be something you are sufficiently interested in write 4000 words on, and as the extended essay needs to be in one of the given subject areas, ensure that your ideas clearly fit into this area.\r\nStep 2: Brainstorming Ideas\r\nTry to get down everything you know about the general topic, even if you are not sure how it relates to your specific question. Here the important is to getting your ideas onto paper, so that you have something to focus upon.\r\nStep 3: Research your Topic\r\nResearch with your essay question and thesis in mind. As you read, ask yourself some key questions, and Consider what kinds of sources are most relevant to your area of research.\r\nStep 4: Organizing the argument structure: preliminary outline\r\nBuild a grouping map outlining what information should be included in each section of your essay. In order to do this, you will need to decide on the structure of your essay. The simplest structure will be to have an Introduction, main body and conclusion.\r\nStep 5: Refine argument: extended outline\r\nBuilding an argument map of your essay should help you to write your essay more clearly, as it provides a clear direction for where your essay is going. In this sense, it is like a map that will help you stay on track with your writing.\r\nStep 6: Consider Evidence\r\nOnce you have built your reasoning map, you need to add in the evidence for your claims. These indicate the basis or evidence that is the foundation for each claim.\r\nStep 7: Assumptions/ Cognitive bias\r\nIdentifying assumptions and their possible objections will strengthen your argument and show that you have thought about underlying issues and arguments. This will allow you to map any objections to the assumptions.\r\nStep 8: Evaluation\r\nEvaluating your map can help you assess the strength of your own argument. This will help with\r\ncritical evaluation in your essay, as you. will not just be considering arguments for and against, but explicitly considering how convincing these arguments are.\r\nStep 9: Draft essay\r\nBegin by copying the text outline of your grouping map and any reasoning maps into your word\r\nprocessor in order. You can then edit the text to write a completed essay.\r\nStep 10: Final Essay\r\nNow that you have a draft of your essay, you will need to revise it several times, write your abstract and bibliography, and finally proofread your essay as a whole, checking for the small errors that are easy to miss when you have become absorbed in your own work.\r\n\r\nThe last but not least, after following these steps your conclusion and the central points and check your Bibliography is complete and accurate. Congratulate yourself. You met the challenge and succeeded!\r\n\r\n\r\n\r\n\r\n', ' \r\n\r\nNAME: NIYIGIRA SALOMON\r\nREGISTRATION NUMBER: 216237173\r\nSCHOOL OF ICT  \r\nCOMPUTER SCIENCE LEVEL II \r\nENGLISH FOR ACADEMIC PURPOSE \r\n\r\nASSIGNMENT: SUMMARY FOR WRITING EXTENDED ESSAY\r\nExtended Essay: Is a research paper of up to 4,000 words giving students an opportunity to conduct independent research or investigation on a topic that interests them. There are 10 steps to achieving a great extended essay, these are:\r\n1.	Choosing a Topic\r\n2. Brainstorming Ideas\r\n3. Research your topic\r\n4. Organizing the argument structure: Preliminary outline\r\n5. Refine Argument: Extended Outline\r\n6. Consider Evidence\r\n7. Assumptions/ cognitive bias\r\n8. Evaluate\r\n9. Draft Essay\r\n10. Final Essay\r\nâ€¢ Annotated bibliography\r\nâ€¢ Write abstract\r\nStep 1: Choosing a topic.\r\nIt has to be something you are sufficiently interested in write 4000 words on, and as the extended essay needs to be in one of the given subject areas, ensure that your ideas clearly fit into this area.\r\nStep 2: Brainstorming Ideas\r\nTry to get down everything you know about the general topic, even if you are not sure how it relates to your specific question. Here the important is to getting your ideas onto paper, so that you have something to focus upon.\r\nStep 3: Research your Topic\r\nResearch with your essay question and thesis in mind. As you read, ask yourself some key questions, and Consider what kinds of sources are most relevant to your area of research.\r\nStep 4: Organizing the argument structure: preliminary outline\r\nBuild a grouping map outlining what information should be included in each section of your essay. In order to do this, you will need to decide on the structure of your essay. The simplest structure will be to have an Introduction, main body and conclusion.\r\nStep 5: Refine argument: extended outline\r\nBuilding an argument map of your essay should help you to write your essay more clearly, as it provides a clear direction for where your essay is going. In this sense, it is like a map that will help you stay on track with your writing.\r\nStep 6: Consider Evidence\r\nOnce you have built your reasoning map, you need to add in the evidence for your claims. These indicate the basis or evidence that is the foundation for each claim.\r\nStep 7: Assumptions/ Cognitive bias\r\nIdentifying assumptions and their possible objections will strengthen your argument and show that you have thought about underlying issues and arguments. This will allow you to map any objections to the assumptions.\r\nStep 8: Evaluation\r\nEvaluating your map can help you assess the strength of your own argument. This will help with\r\ncritical evaluation in your essay, as you. will not just be considering arguments for and against, but explicitly considering how convincing these arguments are.\r\nStep 9: Draft essay\r\nBegin by copying the text outline of your grouping map and any reasoning maps into your word\r\nprocessor in order. You can then edit the text to write a completed essay.\r\nStep 10: Final Essay\r\nNow that you have a draft of your essay, you will need to revise it several times, write your abstract and bibliography, and finally proofread your essay as a whole, checking for the small errors that are easy to miss when you have become absorbed in your own work.\r\n\r\nThe last but not least, after following these steps your conclusion and the central points and check your Bibliography is complete and accurate. Congratulate yourself. You met the challenge and succeeded!\r\n\r\n\r\n\r\n\r\n', ' \r\n\r\nNAME: NIYIGIRA SALOMON\r\nREGISTRATION NUMBER: 216237173\r\nSCHOOL OF ICT  \r\nCOMPUTER SCIENCE LEVEL II \r\nENGLISH FOR ACADEMIC PURPOSE \r\n\r\nASSIGNMENT: SUMMARY FOR WRITING EXTENDED ESSAY\r\nExtended Essay: Is a research paper of up to 4,000 words giving students an opportunity to conduct independent research or investigation on a topic that interests them. There are 10 steps to achieving a great extended essay, these are:\r\n1.	Choosing a Topic\r\n2. Brainstorming Ideas\r\n3. Research your topic\r\n4. Organizing the argument structure: Preliminary outline\r\n5. Refine Argument: Extended Outline\r\n6. Consider Evidence\r\n7. Assumptions/ cognitive bias\r\n8. Evaluate\r\n9. Draft Essay\r\n10. Final Essay\r\nâ€¢ Annotated bibliography\r\nâ€¢ Write abstract\r\nStep 1: Choosing a topic.\r\nIt has to be something you are sufficiently interested in write 4000 words on, and as the extended essay needs to be in one of the given subject areas, ensure that your ideas clearly fit into this area.\r\nStep 2: Brainstorming Ideas\r\nTry to get down everything you know about the general topic, even if you are not sure how it relates to your specific question. Here the important is to getting your ideas onto paper, so that you have something to focus upon.\r\nStep 3: Research your Topic\r\nResearch with your essay question and thesis in mind. As you read, ask yourself some key questions, and Consider what kinds of sources are most relevant to your area of research.\r\nStep 4: Organizing the argument structure: preliminary outline\r\nBuild a grouping map outlining what information should be included in each section of your essay. In order to do this, you will need to decide on the structure of your essay. The simplest structure will be to have an Introduction, main body and conclusion.\r\nStep 5: Refine argument: extended outline\r\nBuilding an argument map of your essay should help you to write your essay more clearly, as it provides a clear direction for where your essay is going. In this sense, it is like a map that will help you stay on track with your writing.\r\nStep 6: Consider Evidence\r\nOnce you have built your reasoning map, you need to add in the evidence for your claims. These indicate the basis or evidence that is the foundation for each claim.\r\nStep 7: Assumptions/ Cognitive bias\r\nIdentifying assumptions and their possible objections will strengthen your argument and show that you have thought about underlying issues and arguments. This will allow you to map any objections to the assumptions.\r\nStep 8: Evaluation\r\nEvaluating your map can help you assess the strength of your own argument. This will help with\r\ncritical evaluation in your essay, as you. will not just be considering arguments for and against, but explicitly considering how convincing these arguments are.\r\nStep 9: Draft essay\r\nBegin by copying the text outline of your grouping map and any reasoning maps into your word\r\nprocessor in order. You can then edit the text to write a completed essay.\r\nStep 10: Final Essay\r\nNow that you have a draft of your essay, you will need to revise it several times, write your abstract and bibliography, and finally proofread your essay as a whole, checking for the small errors that are easy to miss when you have become absorbed in your own work.\r\n\r\nThe last but not least, after following these steps your conclusion and the central points and check your Bibliography is complete and accurate. Congratulate yourself. You met the challenge and succeeded!\r\n\r\n\r\n\r\n\r\n', ' \r\n\r\nNAME: NIYIGIRA SALOMON\r\nREGISTRATION NUMBER: 216237173\r\nSCHOOL OF ICT  \r\nCOMPUTER SCIENCE LEVEL II \r\nENGLISH FOR ACADEMIC PURPOSE \r\n\r\nASSIGNMENT: SUMMARY FOR WRITING EXTENDED ESSAY\r\nExtended Essay: Is a research paper of up to 4,000 words giving students an opportunity to conduct independent research or investigation on a topic that interests them. There are 10 steps to achieving a great extended essay, these are:\r\n1.	Choosing a Topic\r\n2. Brainstorming Ideas\r\n3. Research your topic\r\n4. Organizing the argument structure: Preliminary outline\r\n5. Refine Argument: Extended Outline\r\n6. Consider Evidence\r\n7. Assumptions/ cognitive bias\r\n8. Evaluate\r\n9. Draft Essay\r\n10. Final Essay\r\nâ€¢ Annotated bibliography\r\nâ€¢ Write abstract\r\nStep 1: Choosing a topic.\r\nIt has to be something you are sufficiently interested in write 4000 words on, and as the extended essay needs to be in one of the given subject areas, ensure that your ideas clearly fit into this area.\r\nStep 2: Brainstorming Ideas\r\nTry to get down everything you know about the general topic, even if you are not sure how it relates to your specific question. Here the important is to getting your ideas onto paper, so that you have something to focus upon.\r\nStep 3: Research your Topic\r\nResearch with your essay question and thesis in mind. As you read, ask yourself some key questions, and Consider what kinds of sources are most relevant to your area of research.\r\nStep 4: Organizing the argument structure: preliminary outline\r\nBuild a grouping map outlining what information should be included in each section of your essay. In order to do this, you will need to decide on the structure of your essay. The simplest structure will be to have an Introduction, main body and conclusion.\r\nStep 5: Refine argument: extended outline\r\nBuilding an argument map of your essay should help you to write your essay more clearly, as it provides a clear direction for where your essay is going. In this sense, it is like a map that will help you stay on track with your writing.\r\nStep 6: Consider Evidence\r\nOnce you have built your reasoning map, you need to add in the evidence for your claims. These indicate the basis or evidence that is the foundation for each claim.\r\nStep 7: Assumptions/ Cognitive bias\r\nIdentifying assumptions and their possible objections will strengthen your argument and show that you have thought about underlying issues and arguments. This will allow you to map any objections to the assumptions.\r\nStep 8: Evaluation\r\nEvaluating your map can help you assess the strength of your own argument. This will help with\r\ncritical evaluation in your essay, as you. will not just be considering arguments for and against, but explicitly considering how convincing these arguments are.\r\nStep 9: Draft essay\r\nBegin by copying the text outline of your grouping map and any reasoning maps into your word\r\nprocessor in order. You can then edit the text to write a completed essay.\r\nStep 10: Final Essay\r\nNow that you have a draft of your essay, you will need to revise it several times, write your abstract and bibliography, and finally proofread your essay as a whole, checking for the small errors that are easy to miss when you have become absorbed in your own work.\r\n\r\nThe last but not least, after following these steps your conclusion and the central points and check your Bibliography is complete and accurate. Congratulate yourself. You met the challenge and succeeded!\r\n\r\n\r\n\r\n\r\n', ' \r\n\r\nNAME: NIYIGIRA SALOMON\r\nREGISTRATION NUMBER: 216237173\r\nSCHOOL OF ICT  \r\nCOMPUTER SCIENCE LEVEL II \r\nENGLISH FOR ACADEMIC PURPOSE \r\n\r\nASSIGNMENT: SUMMARY FOR WRITING EXTENDED ESSAY\r\nExtended Essay: Is a research paper of up to 4,000 words giving students an opportunity to conduct independent research or investigation on a topic that interests them. There are 10 steps to achieving a great extended essay, these are:\r\n1.	Choosing a Topic\r\n2. Brainstorming Ideas\r\n3. Research your topic\r\n4. Organizing the argument structure: Preliminary outline\r\n5. Refine Argument: Extended Outline\r\n6. Consider Evidence\r\n7. Assumptions/ cognitive bias\r\n8. Evaluate\r\n9. Draft Essay\r\n10. Final Essay\r\nâ€¢ Annotated bibliography\r\nâ€¢ Write abstract\r\nStep 1: Choosing a topic.\r\nIt has to be something you are sufficiently interested in write 4000 words on, and as the extended essay needs to be in one of the given subject areas, ensure that your ideas clearly fit into this area.\r\nStep 2: Brainstorming Ideas\r\nTry to get down everything you know about the general topic, even if you are not sure how it relates to your specific question. Here the important is to getting your ideas onto paper, so that you have something to focus upon.\r\nStep 3: Research your Topic\r\nResearch with your essay question and thesis in mind. As you read, ask yourself some key questions, and Consider what kinds of sources are most relevant to your area of research.\r\nStep 4: Organizing the argument structure: preliminary outline\r\nBuild a grouping map outlining what information should be included in each section of your essay. In order to do this, you will need to decide on the structure of your essay. The simplest structure will be to have an Introduction, main body and conclusion.\r\nStep 5: Refine argument: extended outline\r\nBuilding an argument map of your essay should help you to write your essay more clearly, as it provides a clear direction for where your essay is going. In this sense, it is like a map that will help you stay on track with your writing.\r\nStep 6: Consider Evidence\r\nOnce you have built your reasoning map, you need to add in the evidence for your claims. These indicate the basis or evidence that is the foundation for each claim.\r\nStep 7: Assumptions/ Cognitive bias\r\nIdentifying assumptions and their possible objections will strengthen your argument and show that you have thought about underlying issues and arguments. This will allow you to map any objections to the assumptions.\r\nStep 8: Evaluation\r\nEvaluating your map can help you assess the strength of your own argument. This will help with\r\ncritical evaluation in your essay, as you. will not just be considering arguments for and against, but explicitly considering how convincing these arguments are.\r\nStep 9: Draft essay\r\nBegin by copying the text outline of your grouping map and any reasoning maps into your word\r\nprocessor in order. You can then edit the text to write a completed essay.\r\nStep 10: Final Essay\r\nNow that you have a draft of your essay, you will need to revise it several times, write your abstract and bibliography, and finally proofread your essay as a whole, checking for the small errors that are easy to miss when you have become absorbed in your own work.\r\n\r\nThe last but not least, after following these steps your conclusion and the central points and check your Bibliography is complete and accurate. Congratulate yourself. You met the challenge and succeeded!\r\n\r\n\r\n\r\n\r\n', ' \r\n\r\nNAME: NIYIGIRA SALOMON\r\nREGISTRATION NUMBER: 216237173\r\nSCHOOL OF ICT  \r\nCOMPUTER SCIENCE LEVEL II \r\nENGLISH FOR ACADEMIC PURPOSE \r\n\r\nASSIGNMENT: SUMMARY FOR WRITING EXTENDED ESSAY\r\nExtended Essay: Is a research paper of up to 4,000 words giving students an opportunity to conduct independent research or investigation on a topic that interests them. There are 10 steps to achieving a great extended essay, these are:\r\n1.	Choosing a Topic\r\n2. Brainstorming Ideas\r\n3. Research your topic\r\n4. Organizing the argument structure: Preliminary outline\r\n5. Refine Argument: Extended Outline\r\n6. Consider Evidence\r\n7. Assumptions/ cognitive bias\r\n8. Evaluate\r\n9. Draft Essay\r\n10. Final Essay\r\nâ€¢ Annotated bibliography\r\nâ€¢ Write abstract\r\nStep 1: Choosing a topic.\r\nIt has to be something you are sufficiently interested in write 4000 words on, and as the extended essay needs to be in one of the given subject areas, ensure that your ideas clearly fit into this area.\r\nStep 2: Brainstorming Ideas\r\nTry to get down everything you know about the general topic, even if you are not sure how it relates to your specific question. Here the important is to getting your ideas onto paper, so that you have something to focus upon.\r\nStep 3: Research your Topic\r\nResearch with your essay question and thesis in mind. As you read, ask yourself some key questions, and Consider what kinds of sources are most relevant to your area of research.\r\nStep 4: Organizing the argument structure: preliminary outline\r\nBuild a grouping map outlining what information should be included in each section of your essay. In order to do this, you will need to decide on the structure of your essay. The simplest structure will be to have an Introduction, main body and conclusion.\r\nStep 5: Refine argument: extended outline\r\nBuilding an argument map of your essay should help you to write your essay more clearly, as it provides a clear direction for where your essay is going. In this sense, it is like a map that will help you stay on track with your writing.\r\nStep 6: Consider Evidence\r\nOnce you have built your reasoning map, you need to add in the evidence for your claims. These indicate the basis or evidence that is the foundation for each claim.\r\nStep 7: Assumptions/ Cognitive bias\r\nIdentifying assumptions and their possible objections will strengthen your argument and show that you have thought about underlying issues and arguments. This will allow you to map any objections to the assumptions.\r\nStep 8: Evaluation\r\nEvaluating your map can help you assess the strength of your own argument. This will help with\r\ncritical evaluation in your essay, as you. will not just be considering arguments for and against, but explicitly considering how convincing these arguments are.\r\nStep 9: Draft essay\r\nBegin by copying the text outline of your grouping map and any reasoning maps into your word\r\nprocessor in order. You can then edit the text to write a completed essay.\r\nStep 10: Final Essay\r\nNow that you have a draft of your essay, you will need to revise it several times, write your abstract and bibliography, and finally proofread your essay as a whole, checking for the small errors that are easy to miss when you have become absorbed in your own work.\r\n\r\nThe last but not least, after following these steps your conclusion and the central points and check your Bibliography is complete and accurate. Congratulate yourself. You met the challenge and succeeded!\r\n\r\n\r\n\r\n\r\n', ' \r\n\r\nNAME: NIYIGIRA SALOMON\r\nREGISTRATION NUMBER: 216237173\r\nSCHOOL OF ICT  \r\nCOMPUTER SCIENCE LEVEL II \r\nENGLISH FOR ACADEMIC PURPOSE \r\n\r\nASSIGNMENT: SUMMARY FOR WRITING EXTENDED ESSAY\r\nExtended Essay: Is a research paper of up to 4,000 words giving students an opportunity to conduct independent research or investigation on a topic that interests them. There are 10 steps to achieving a great extended essay, these are:\r\n1.	Choosing a Topic\r\n2. Brainstorming Ideas\r\n3. Research your topic\r\n4. Organizing the argument structure: Preliminary outline\r\n5. Refine Argument: Extended Outline\r\n6. Consider Evidence\r\n7. Assumptions/ cognitive bias\r\n8. Evaluate\r\n9. Draft Essay\r\n10. Final Essay\r\nâ€¢ Annotated bibliography\r\nâ€¢ Write abstract\r\nStep 1: Choosing a topic.\r\nIt has to be something you are sufficiently interested in write 4000 words on, and as the extended essay needs to be in one of the given subject areas, ensure that your ideas clearly fit into this area.\r\nStep 2: Brainstorming Ideas\r\nTry to get down everything you know about the general topic, even if you are not sure how it relates to your specific question. Here the important is to getting your ideas onto paper, so that you have something to focus upon.\r\nStep 3: Research your Topic\r\nResearch with your essay question and thesis in mind. As you read, ask yourself some key questions, and Consider what kinds of sources are most relevant to your area of research.\r\nStep 4: Organizing the argument structure: preliminary outline\r\nBuild a grouping map outlining what information should be included in each section of your essay. In order to do this, you will need to decide on the structure of your essay. The simplest structure will be to have an Introduction, main body and conclusion.\r\nStep 5: Refine argument: extended outline\r\nBuilding an argument map of your essay should help you to write your essay more clearly, as it provides a clear direction for where your essay is going. In this sense, it is like a map that will help you stay on track with your writing.\r\nStep 6: Consider Evidence\r\nOnce you have built your reasoning map, you need to add in the evidence for your claims. These indicate the basis or evidence that is the foundation for each claim.\r\nStep 7: Assumptions/ Cognitive bias\r\nIdentifying assumptions and their possible objections will strengthen your argument and show that you have thought about underlying issues and arguments. This will allow you to map any objections to the assumptions.\r\nStep 8: Evaluation\r\nEvaluating your map can help you assess the strength of your own argument. This will help with\r\ncritical evaluation in your essay, as you. will not just be considering arguments for and against, but explicitly considering how convincing these arguments are.\r\nStep 9: Draft essay\r\nBegin by copying the text outline of your grouping map and any reasoning maps into your word\r\nprocessor in order. You can then edit the text to write a completed essay.\r\nStep 10: Final Essay\r\nNow that you have a draft of your essay, you will need to revise it several times, write your abstract and bibliography, and finally proofread your essay as a whole, checking for the small errors that are easy to miss when you have become absorbed in your own work.\r\n\r\nThe last but not least, after following these steps your conclusion and the central points and check your Bibliography is complete and accurate. Congratulate yourself. You met the challenge and succeeded!\r\n\r\n\r\n\r\n\r\n', 'fsdafsdf', 'fsdfsdfsd', ' \r\n\r\nNAME: NIYIGIRA SALOMON\r\nREGISTRATION NUMBER: 216237173\r\nSCHOOL OF ICT  \r\nCOMPUTER SCIENCE LEVEL II \r\nENGLISH FOR ACADEMIC PURPOSE \r\n\r\nASSIGNMENT: SUMMARY FOR WRITING EXTENDED ESSAY\r\nExtended Essay: Is a research paper of up to 4,000 words giving students an opportunity to conduct independent research or investigation on a topic that interests them. There are 10 steps to achieving a great extended essay, these are:\r\n1.	Choosing a Topic\r\n2. Brainstorming Ideas\r\n3. Research your topic\r\n4. Organizing the argument structure: Preliminary outline\r\n5. Refine Argument: Extended Outline\r\n6. Consider Evidence\r\n7. Assumptions/ cognitive bias\r\n8. Evaluate\r\n9. Draft Essay\r\n10. Final Essay\r\nâ€¢ Annotated bibliography\r\nâ€¢ Write abstract\r\nStep 1: Choosing a topic.\r\nIt has to be something you are sufficiently interested in write 4000 words on, and as the extended essay needs to be in one of the given subject areas, ensure that your ideas clearly fit into this area.\r\nStep 2: Brainstorming Ideas\r\nTry to get down everything you know about the general topic, even if you are not sure how it relates to your specific question. Here the important is to getting your ideas onto paper, so that you have something to focus upon.\r\nStep 3: Research your Topic\r\nResearch with your essay question and thesis in mind. As you read, ask yourself some key questions, and Consider what kinds of sources are most relevant to your area of research.\r\nStep 4: Organizing the argument structure: preliminary outline\r\nBuild a grouping map outlining what information should be included in each section of your essay. In order to do this, you will need to decide on the structure of your essay. The simplest structure will be to have an Introduction, main body and conclusion.\r\nStep 5: Refine argument: extended outline\r\nBuilding an argument map of your essay should help you to write your essay more clearly, as it provides a clear direction for where your essay is going. In this sense, it is like a map that will help you stay on track with your writing.\r\nStep 6: Consider Evidence\r\nOnce you have built your reasoning map, you need to add in the evidence for your claims. These indicate the basis or evidence that is the foundation for each claim.\r\nStep 7: Assumptions/ Cognitive bias\r\nIdentifying assumptions and their possible objections will strengthen your argument and show that you have thought about underlying issues and arguments. This will allow you to map any objections to the assumptions.\r\nStep 8: Evaluation\r\nEvaluating your map can help you assess the strength of your own argument. This will help with\r\ncritical evaluation in your essay, as you. will not just be considering arguments for and against, but explicitly considering how convincing these arguments are.\r\nStep 9: Draft essay\r\nBegin by copying the text outline of your grouping map and any reasoning maps into your word\r\nprocessor in order. You can then edit the text to write a completed essay.\r\nStep 10: Final Essay\r\nNow that you have a draft of your essay, you will need to revise it several times, write your abstract and bibliography, and finally proofread your essay as a whole, checking for the small errors that are easy to miss when you have become absorbed in your own work.\r\n\r\nThe last but not least, after following these steps your conclusion and the central points and check your Bibliography is complete and accurate. Congratulate yourself. You met the challenge and succeeded!\r\n\r\n\r\n\r\n\r\n'),
(6, 0x31372f30372f32303137, '', '', '', '', '', '', '', '', '', ''),
(7, 0x31372f30372f32303137, '', '', '', '', '', '', '', '', '', ''),
(8, 0x323031372d30382d31312031363a30303a3038, '', '', '', '', '', '', '', '', '', ''),
(9, 0x323031372d30382d31342030393a35383a3336, 'dghjdghgdhgadfgzafasds', 'dghjdghgdhgadfgzafasds', 'dghjdghgdhgadfgzafasds', 'dghjdghgdhgadfgzafasds', 'dghjdghgdhgadfgzafasds', 'dghjdghgdhgadfgzafasds', 'dghjdghgdhgadfgzafasds', 'salomon', 'ict', 'dghjdghgdhgadfgzafasds'),
(10, 0x323031372d30382d31342030393a35393a3031, 'gfthgfhhtgfhgfh', 'ddghjdghgdhgadfgzafasds', 'dghjdghgdhgadfgzafasds', 'dghjdghgdhgadfgzafasds', 'dghjdghgdhgadfgzafasds', 'dghjdghgdhgadfgzafasds', 'dghjdghgdhgadfgzafasds', 'salomon', 'ict', 'dghjdghgdhgadfgzafasds'),
(11, 0x323031372d30382d31342031303a30303a3236, 'sw', 'sdf', 'fsdde', 'dsf', 'dfs', 'sdf', 'sdfg', 'sdf', 'sdf', 'dsf');

-- --------------------------------------------------------

--
-- Table structure for table `reports`
--

CREATE TABLE IF NOT EXISTS `reports` (
  `rid` int(255) NOT NULL AUTO_INCREMENT,
  `dates` varchar(255) NOT NULL,
  `planact` varchar(255) NOT NULL,
  `doneact` varchar(255) NOT NULL,
  `nodoneact` varchar(255) NOT NULL,
  `noplanact` varchar(255) NOT NULL,
  `prob` varchar(255) NOT NULL,
  `sugg` varchar(255) NOT NULL,
  `observ` varchar(255) NOT NULL,
  `worker` varchar(255) NOT NULL,
  `post` varchar(255) NOT NULL,
  `comment` varchar(255) NOT NULL,
  `id` int(255) DEFAULT NULL,
  PRIMARY KEY (`rid`),
  KEY `reports_ibfk_1` (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 ROW_FORMAT=REDUNDANT AUTO_INCREMENT=7 ;

--
-- Dumping data for table `reports`
--

INSERT INTO `reports` (`rid`, `dates`, `planact`, `doneact`, `nodoneact`, `noplanact`, `prob`, `sugg`, `observ`, `worker`, `post`, `comment`, `id`) VALUES
(1, '2017-08-14 10:01:54', '', '', '', '', '', '', '', '', '', '', 3),
(2, '2017-08-15 14:11:30', '', '', '', '', '', '', '', '', '', '', 3),
(3, '2017-08-22 18:44:38', '', '', '', '', '', '', '', '', '', '', 3),
(4, '2017-08-22 18:45:03', '', '', '', '', '', '', '', '', '', '', 3),
(5, '2017-09-07 12:04:54', '', '', '', '', '', '', '', '', '', '', 3),
(6, '2017-09-07 12:10:10', '', '', '', '', '', '', '', '', '', '', 3);

-- --------------------------------------------------------

--
-- Table structure for table `vid`
--

CREATE TABLE IF NOT EXISTS `vid` (
  `description` varchar(255) NOT NULL,
  `filename` varchar(255) NOT NULL,
  `fileextension` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `vid`
--

INSERT INTO `vid` (`description`, `filename`, `fileextension`) VALUES
('$description', '$name', '$fileextension');

-- --------------------------------------------------------

--
-- Table structure for table `videos`
--

CREATE TABLE IF NOT EXISTS `videos` (
  `Id` int(16) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `categorie` varchar(100) NOT NULL,
  `year` int(11) NOT NULL,
  `Video_Url` text NOT NULL,
  `icon_url` text NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `videos`
--

INSERT INTO `videos` (`Id`, `name`, `categorie`, `year`, `Video_Url`, `icon_url`) VALUES
(1, 'indirimbo', 'choir', 2017, 'img/vids/kk.mp4', 'img/vids/eglise.jpg'),
(2, 'indirimbo', 'choir', 2017, 'img/vids/kk.mp4', 'img/vids/eglise.jpg'),
(4, 'Azasanga urihe by kamugisha ronald( official audio 2015)', 'event', 2017, 'img/vids/Azasanga urihe by kamugisha ronald( official audio 2015).mp4', 'img/vids/ss.jpg'),
(5, 'dufite umwami by intumwa', 'event', 2016, 'img/vids/kkg.vob', 'img/vids/Capture.png'),
(6, 'Amfitiye byinshi', 'choir', 2015, 'img/vidsAmfitiye byinshi.mp3', 'img/vids/ss.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `views`
--

CREATE TABLE IF NOT EXISTS `views` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `dates` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=825 ;

--
-- Dumping data for table `views`
--

INSERT INTO `views` (`id`, `dates`) VALUES
(1, '17/07/2017'),
(2, '17/07/2017'),
(3, '17/07/2017'),
(4, '17/07/2017'),
(5, '17/07/2017'),
(6, '17/07/2017'),
(7, '17/07/2017'),
(8, '17/07/2017'),
(9, '17/07/2017'),
(10, '17/07/2017'),
(11, '17/07/2017'),
(12, '17/07/2017'),
(13, '17/07/2017'),
(14, '17/07/2017'),
(15, '17/07/2017'),
(16, '17/07/2017'),
(17, '17/07/2017'),
(18, '17/07/2017'),
(19, '17/07/2017'),
(20, '17/07/2017'),
(21, '17/07/2017'),
(22, '17/07/2017'),
(23, '18/07/2017'),
(24, '18/07/2017'),
(25, '18/07/2017'),
(26, '18/07/2017'),
(27, '18/07/2017'),
(28, '18/07/2017'),
(29, '18/07/2017'),
(30, '18/07/2017'),
(31, '18/07/2017'),
(32, '18/07/2017'),
(33, '18/07/2017'),
(34, '18/07/2017'),
(35, '18/07/2017'),
(36, '18/07/2017'),
(37, '18/07/2017'),
(38, '18/07/2017'),
(39, '18/07/2017'),
(40, '18/07/2017'),
(41, '18/07/2017'),
(42, '18/07/2017'),
(43, '18/07/2017'),
(44, '18/07/2017'),
(45, '18/07/2017'),
(46, '18/07/2017'),
(47, '19/07/2017'),
(48, '19/07/2017'),
(49, '19/07/2017'),
(50, '19/07/2017'),
(51, '19/07/2017'),
(52, '19/07/2017'),
(53, '19/07/2017'),
(54, '19/07/2017'),
(55, '19/07/2017'),
(56, '19/07/2017'),
(57, '19/07/2017'),
(58, '19/07/2017'),
(59, '19/07/2017'),
(60, '19/07/2017'),
(61, '19/07/2017'),
(62, '19/07/2017'),
(63, '19/07/2017'),
(64, '19/07/2017'),
(65, '19/07/2017'),
(66, '19/07/2017'),
(67, '19/07/2017'),
(68, '19/07/2017'),
(69, '19/07/2017'),
(70, '19/07/2017'),
(71, '19/07/2017'),
(72, '19/07/2017'),
(73, '19/07/2017'),
(74, '19/07/2017'),
(75, '19/07/2017'),
(76, '19/07/2017'),
(77, '19/07/2017'),
(78, '20/07/2017'),
(79, '20/07/2017'),
(80, '20/07/2017'),
(81, '20/07/2017'),
(82, '20/07/2017'),
(83, '20/07/2017'),
(84, '20/07/2017'),
(85, '20/07/2017'),
(86, '20/07/2017'),
(87, '20/07/2017'),
(88, '20/07/2017'),
(89, '20/07/2017'),
(90, '20/07/2017'),
(91, '20/07/2017'),
(92, '20/07/2017'),
(93, '20/07/2017'),
(94, '20/07/2017'),
(95, '20/07/2017'),
(96, '20/07/2017'),
(97, '20/07/2017'),
(98, '20/07/2017'),
(99, '20/07/2017'),
(100, '20/07/2017'),
(101, '20/07/2017'),
(102, '20/07/2017'),
(103, '21/07/2017'),
(104, '21/07/2017'),
(105, '21/07/2017'),
(106, '21/07/2017'),
(107, '21/07/2017'),
(108, '21/07/2017'),
(109, '21/07/2017'),
(110, '21/07/2017'),
(111, '21/07/2017'),
(112, '21/07/2017'),
(113, '21/07/2017'),
(114, '23/07/2017'),
(115, '23/07/2017'),
(116, '23/07/2017'),
(117, '23/07/2017'),
(118, '23/07/2017'),
(119, '23/07/2017'),
(120, '23/07/2017'),
(121, '23/07/2017'),
(122, '23/07/2017'),
(123, '23/07/2017'),
(124, '23/07/2017'),
(125, '23/07/2017'),
(126, '23/07/2017'),
(127, '23/07/2017'),
(128, '23/07/2017'),
(129, '23/07/2017'),
(130, '23/07/2017'),
(131, '23/07/2017'),
(132, '23/07/2017'),
(133, '24/07/2017'),
(134, '24/07/2017'),
(135, '24/07/2017'),
(136, '24/07/2017'),
(137, '24/07/2017'),
(138, '24/07/2017'),
(139, '24/07/2017'),
(140, '24/07/2017'),
(141, '24/07/2017'),
(142, '24/07/2017'),
(143, '24/07/2017'),
(144, '24/07/2017'),
(145, '24/07/2017'),
(146, '24/07/2017'),
(147, '24/07/2017'),
(148, '24/07/2017'),
(149, '24/07/2017'),
(150, '24/07/2017'),
(151, '24/07/2017'),
(152, '24/07/2017'),
(153, '24/07/2017'),
(154, '24/07/2017'),
(155, '24/07/2017'),
(156, '24/07/2017'),
(157, '24/07/2017'),
(158, '24/07/2017'),
(159, '24/07/2017'),
(160, '24/07/2017'),
(161, '24/07/2017'),
(162, '24/07/2017'),
(163, '24/07/2017'),
(164, '24/07/2017'),
(165, '24/07/2017'),
(166, '24/07/2017'),
(167, '24/07/2017'),
(168, '24/07/2017'),
(169, '24/07/2017'),
(170, '24/07/2017'),
(171, '24/07/2017'),
(172, '24/07/2017'),
(173, '24/07/2017'),
(174, '24/07/2017'),
(175, '24/07/2017'),
(176, '24/07/2017'),
(177, '24/07/2017'),
(178, '24/07/2017'),
(179, '24/07/2017'),
(180, '24/07/2017'),
(181, '24/07/2017'),
(182, '24/07/2017'),
(183, '24/07/2017'),
(184, '24/07/2017'),
(185, '24/07/2017'),
(186, '24/07/2017'),
(187, '24/07/2017'),
(188, '25/07/2017'),
(189, '25/07/2017'),
(190, '25/07/2017'),
(191, '25/07/2017'),
(192, '25/07/2017'),
(193, '25/07/2017'),
(194, '25/07/2017'),
(195, '25/07/2017'),
(196, '25/07/2017'),
(197, '25/07/2017'),
(198, '25/07/2017'),
(199, '26/07/2017'),
(200, '26/07/2017'),
(201, '26/07/2017'),
(202, '26/07/2017'),
(203, '26/07/2017'),
(204, '26/07/2017'),
(205, '26/07/2017'),
(206, '26/07/2017'),
(207, '27/07/2017'),
(208, '27/07/2017'),
(209, '27/07/2017'),
(210, '27/07/2017'),
(211, '27/07/2017'),
(212, '27/07/2017'),
(213, '31/07/2017'),
(214, '31/07/2017'),
(215, '31/07/2017'),
(216, '31/07/2017'),
(217, '31/07/2017'),
(218, '31/07/2017'),
(219, '31/07/2017'),
(220, '31/07/2017'),
(221, '31/07/2017'),
(222, '31/07/2017'),
(223, '31/07/2017'),
(224, '31/07/2017'),
(225, '31/07/2017'),
(226, '31/07/2017'),
(227, '31/07/2017'),
(228, '31/07/2017'),
(229, '31/07/2017'),
(230, '31/07/2017'),
(231, '31/07/2017'),
(232, '31/07/2017'),
(233, '31/07/2017'),
(234, '31/07/2017'),
(235, '31/07/2017'),
(236, '31/07/2017'),
(237, '31/07/2017'),
(238, '31/07/2017'),
(239, '31/07/2017'),
(240, '31/07/2017'),
(241, '31/07/2017'),
(242, '31/07/2017'),
(243, '31/07/2017'),
(244, '31/07/2017'),
(245, '31/07/2017'),
(246, '31/07/2017'),
(247, '31/07/2017'),
(248, '31/07/2017'),
(249, '31/07/2017'),
(250, '31/07/2017'),
(251, '31/07/2017'),
(252, '31/07/2017'),
(253, '31/07/2017'),
(254, '31/07/2017'),
(255, '02/08/2017'),
(256, '02/08/2017'),
(257, '02/08/2017'),
(258, '02/08/2017'),
(259, '02/08/2017'),
(260, '02/08/2017'),
(261, '02/08/2017'),
(262, '02/08/2017'),
(263, '02/08/2017'),
(264, '02/08/2017'),
(265, '02/08/2017'),
(266, '02/08/2017'),
(267, '02/08/2017'),
(268, '02/08/2017'),
(269, '02/08/2017'),
(270, '02/08/2017'),
(271, '02/08/2017'),
(272, '02/08/2017'),
(273, '02/08/2017'),
(274, '02/08/2017'),
(275, '02/08/2017'),
(276, '02/08/2017'),
(277, '02/08/2017'),
(278, '03/08/2017'),
(279, '03/08/2017'),
(280, '04/08/2017'),
(281, '04/08/2017'),
(282, '04/08/2017'),
(283, '04/08/2017'),
(284, '04/08/2017'),
(285, '04/08/2017'),
(286, '04/08/2017'),
(287, '04/08/2017'),
(288, '04/08/2017'),
(289, '04/08/2017'),
(290, '04/08/2017'),
(291, '04/08/2017'),
(292, '04/08/2017'),
(293, '04/08/2017'),
(294, '04/08/2017'),
(295, '04/08/2017'),
(296, '04/08/2017'),
(297, '04/08/2017'),
(298, '04/08/2017'),
(299, '04/08/2017'),
(300, '04/08/2017'),
(301, '04/08/2017'),
(302, '04/08/2017'),
(303, '04/08/2017'),
(304, '04/08/2017'),
(305, '04/08/2017'),
(306, '04/08/2017'),
(307, '04/08/2017'),
(308, '04/08/2017'),
(309, '04/08/2017'),
(310, '05/08/2017'),
(311, '05/08/2017'),
(312, '05/08/2017'),
(313, '05/08/2017'),
(314, '05/08/2017'),
(315, '05/08/2017'),
(316, '05/08/2017'),
(317, '05/08/2017'),
(318, '05/08/2017'),
(319, '05/08/2017'),
(320, '05/08/2017'),
(321, '05/08/2017'),
(322, '05/08/2017'),
(323, '05/08/2017'),
(324, '05/08/2017'),
(325, '05/08/2017'),
(326, '07/08/2017'),
(327, '07/08/2017'),
(328, '07/08/2017'),
(329, '07/08/2017'),
(330, '07/08/2017'),
(331, '07/08/2017'),
(332, '07/08/2017'),
(333, '07/08/2017'),
(334, '07/08/2017'),
(335, '07/08/2017'),
(336, '07/08/2017'),
(337, '07/08/2017'),
(338, '07/08/2017'),
(339, '07/08/2017'),
(340, '07/08/2017'),
(341, '07/08/2017'),
(342, '07/08/2017'),
(343, '07/08/2017'),
(344, '07/08/2017'),
(345, '07/08/2017'),
(346, '07/08/2017'),
(347, '07/08/2017'),
(348, '07/08/2017'),
(349, '07/08/2017'),
(350, '07/08/2017'),
(351, '07/08/2017'),
(352, '07/08/2017'),
(353, '07/08/2017'),
(354, '07/08/2017'),
(355, '07/08/2017'),
(356, '07/08/2017'),
(357, '07/08/2017'),
(358, '07/08/2017'),
(359, '08/08/2017'),
(360, '08/08/2017'),
(361, '08/08/2017'),
(362, '08/08/2017'),
(363, '08/08/2017'),
(364, '08/08/2017'),
(365, '08/08/2017'),
(366, '08/08/2017'),
(367, '08/08/2017'),
(368, '08/08/2017'),
(369, '08/08/2017'),
(370, '08/08/2017'),
(371, '08/08/2017'),
(372, '08/08/2017'),
(373, '08/08/2017'),
(374, '09/08/2017'),
(375, '09/08/2017'),
(376, '09/08/2017'),
(377, '09/08/2017'),
(378, '09/08/2017'),
(379, '09/08/2017'),
(380, '09/08/2017'),
(381, '09/08/2017'),
(382, '09/08/2017'),
(383, '10/08/2017'),
(384, '10/08/2017'),
(385, '10/08/2017'),
(386, '10/08/2017'),
(387, '10/08/2017'),
(388, '10/08/2017'),
(389, '10/08/2017'),
(390, '10/08/2017'),
(391, '10/08/2017'),
(392, '10/08/2017'),
(393, '11/08/2017'),
(394, '11/08/2017'),
(395, '11/08/2017'),
(396, '11/08/2017'),
(397, '11/08/2017'),
(398, '11/08/2017'),
(399, '11/08/2017'),
(400, '11/08/2017'),
(401, '11/08/2017'),
(402, '11/08/2017'),
(403, '11/08/2017'),
(404, '11/08/2017'),
(405, '11/08/2017'),
(406, '11/08/2017'),
(407, '11/08/2017'),
(408, '11/08/2017'),
(409, '11/08/2017'),
(410, '11/08/2017'),
(411, '11/08/2017'),
(412, '11/08/2017'),
(413, '11/08/2017'),
(414, '11/08/2017'),
(415, '11/08/2017'),
(416, '11/08/2017'),
(417, '11/08/2017'),
(418, '11/08/2017'),
(419, '11/08/2017'),
(420, '11/08/2017'),
(421, '11/08/2017'),
(422, '12/08/2017'),
(423, '12/08/2017'),
(424, '12/08/2017'),
(425, '12/08/2017'),
(426, '12/08/2017'),
(427, '12/08/2017'),
(428, '12/08/2017'),
(429, '12/08/2017'),
(430, '12/08/2017'),
(431, '12/08/2017'),
(432, '14/08/2017'),
(433, '14/08/2017'),
(434, '14/08/2017'),
(435, '14/08/2017'),
(436, '14/08/2017'),
(437, '14/08/2017'),
(438, '14/08/2017'),
(439, '14/08/2017'),
(440, '14/08/2017'),
(441, '14/08/2017'),
(442, '14/08/2017'),
(443, '14/08/2017'),
(444, '14/08/2017'),
(445, '14/08/2017'),
(446, '14/08/2017'),
(447, '14/08/2017'),
(448, '14/08/2017'),
(449, '14/08/2017'),
(450, '14/08/2017'),
(451, '14/08/2017'),
(452, '14/08/2017'),
(453, '14/08/2017'),
(454, '14/08/2017'),
(455, '14/08/2017'),
(456, '15/08/2017'),
(457, '15/08/2017'),
(458, '15/08/2017'),
(459, '16/08/2017'),
(460, '16/08/2017'),
(461, '16/08/2017'),
(462, '19/08/2017'),
(463, '19/08/2017'),
(464, '19/08/2017'),
(465, '21/08/2017'),
(466, '21/08/2017'),
(467, '21/08/2017'),
(468, '22/08/2017'),
(469, '22/08/2017'),
(470, '22/08/2017'),
(471, '22/08/2017'),
(472, '22/08/2017'),
(473, '22/08/2017'),
(474, '22/08/2017'),
(475, '22/08/2017'),
(476, '22/08/2017'),
(477, '22/08/2017'),
(478, '22/08/2017'),
(479, '22/08/2017'),
(480, '22/08/2017'),
(481, '22/08/2017'),
(482, '22/08/2017'),
(483, '22/08/2017'),
(484, '22/08/2017'),
(485, '22/08/2017'),
(486, '22/08/2017'),
(487, '22/08/2017'),
(488, '22/08/2017'),
(489, '22/08/2017'),
(490, '22/08/2017'),
(491, '22/08/2017'),
(492, '22/08/2017'),
(493, '23/08/2017'),
(494, '24/08/2017'),
(495, '24/08/2017'),
(496, '24/08/2017'),
(497, '24/08/2017'),
(498, '24/08/2017'),
(499, '24/08/2017'),
(500, '24/08/2017'),
(501, '24/08/2017'),
(502, '25/08/2017'),
(503, '25/08/2017'),
(504, '25/08/2017'),
(505, '25/08/2017'),
(506, '25/08/2017'),
(507, '25/08/2017'),
(508, '25/08/2017'),
(509, '25/08/2017'),
(510, '25/08/2017'),
(511, '25/08/2017'),
(512, '25/08/2017'),
(513, '25/08/2017'),
(514, '25/08/2017'),
(515, '25/08/2017'),
(516, '25/08/2017'),
(517, '25/08/2017'),
(518, '25/08/2017'),
(519, '25/08/2017'),
(520, '25/08/2017'),
(521, '25/08/2017'),
(522, '25/08/2017'),
(523, '25/08/2017'),
(524, '25/08/2017'),
(525, '28/08/2017'),
(526, '28/08/2017'),
(527, '28/08/2017'),
(528, '28/08/2017'),
(529, '28/08/2017'),
(530, '28/08/2017'),
(531, '28/08/2017'),
(532, '28/08/2017'),
(533, '29/08/2017'),
(534, '29/08/2017'),
(535, '29/08/2017'),
(536, '29/08/2017'),
(537, '29/08/2017'),
(538, '29/08/2017'),
(539, '29/08/2017'),
(540, '29/08/2017'),
(541, '29/08/2017'),
(542, '29/08/2017'),
(543, '30/08/2017'),
(544, '30/08/2017'),
(545, '30/08/2017'),
(546, '30/08/2017'),
(547, '31/08/2017'),
(548, '31/08/2017'),
(549, '31/08/2017'),
(550, '02/09/2017'),
(551, '02/09/2017'),
(552, '02/09/2017'),
(553, '02/09/2017'),
(554, '02/09/2017'),
(555, '02/09/2017'),
(556, '02/09/2017'),
(557, '02/09/2017'),
(558, '02/09/2017'),
(559, '02/09/2017'),
(560, '02/09/2017'),
(561, '02/09/2017'),
(562, '02/09/2017'),
(563, '02/09/2017'),
(564, '02/09/2017'),
(565, '02/09/2017'),
(566, '02/09/2017'),
(567, '02/09/2017'),
(568, '02/09/2017'),
(569, '02/09/2017'),
(570, '02/09/2017'),
(571, '02/09/2017'),
(572, '02/09/2017'),
(573, '02/09/2017'),
(574, '02/09/2017'),
(575, '02/09/2017'),
(576, '02/09/2017'),
(577, '02/09/2017'),
(578, '02/09/2017'),
(579, '02/09/2017'),
(580, '02/09/2017'),
(581, '02/09/2017'),
(582, '02/09/2017'),
(583, '02/09/2017'),
(584, '02/09/2017'),
(585, '02/09/2017'),
(586, '02/09/2017'),
(587, '02/09/2017'),
(588, '02/09/2017'),
(589, '02/09/2017'),
(590, '02/09/2017'),
(591, '02/09/2017'),
(592, '02/09/2017'),
(593, '02/09/2017'),
(594, '02/09/2017'),
(595, '02/09/2017'),
(596, '02/09/2017'),
(597, '02/09/2017'),
(598, '02/09/2017'),
(599, '02/09/2017'),
(600, '02/09/2017'),
(601, '02/09/2017'),
(602, '02/09/2017'),
(603, '02/09/2017'),
(604, '02/09/2017'),
(605, '02/09/2017'),
(606, '04/09/2017'),
(607, '04/09/2017'),
(608, '04/09/2017'),
(609, '04/09/2017'),
(610, '04/09/2017'),
(611, '04/09/2017'),
(612, '04/09/2017'),
(613, '04/09/2017'),
(614, '04/09/2017'),
(615, '04/09/2017'),
(616, '04/09/2017'),
(617, '04/09/2017'),
(618, '04/09/2017'),
(619, '04/09/2017'),
(620, '04/09/2017'),
(621, '04/09/2017'),
(622, '04/09/2017'),
(623, '04/09/2017'),
(624, '04/09/2017'),
(625, '04/09/2017'),
(626, '04/09/2017'),
(627, '04/09/2017'),
(628, '04/09/2017'),
(629, '04/09/2017'),
(630, '04/09/2017'),
(631, '04/09/2017'),
(632, '04/09/2017'),
(633, '04/09/2017'),
(634, '04/09/2017'),
(635, '04/09/2017'),
(636, '04/09/2017'),
(637, '04/09/2017'),
(638, '04/09/2017'),
(639, '04/09/2017'),
(640, '04/09/2017'),
(641, '04/09/2017'),
(642, '04/09/2017'),
(643, '04/09/2017'),
(644, '04/09/2017'),
(645, '04/09/2017'),
(646, '04/09/2017'),
(647, '05/09/2017'),
(648, '05/09/2017'),
(649, '05/09/2017'),
(650, '05/09/2017'),
(651, '05/09/2017'),
(652, '05/09/2017'),
(653, '05/09/2017'),
(654, '05/09/2017'),
(655, '05/09/2017'),
(656, '05/09/2017'),
(657, '05/09/2017'),
(658, '05/09/2017'),
(659, '05/09/2017'),
(660, '05/09/2017'),
(661, '05/09/2017'),
(662, '05/09/2017'),
(663, '05/09/2017'),
(664, '05/09/2017'),
(665, '05/09/2017'),
(666, '05/09/2017'),
(667, '05/09/2017'),
(668, '05/09/2017'),
(669, '05/09/2017'),
(670, '05/09/2017'),
(671, '05/09/2017'),
(672, '05/09/2017'),
(673, '05/09/2017'),
(674, '05/09/2017'),
(675, '05/09/2017'),
(676, '05/09/2017'),
(677, '05/09/2017'),
(678, '05/09/2017'),
(679, '05/09/2017'),
(680, '05/09/2017'),
(681, '05/09/2017'),
(682, '05/09/2017'),
(683, '05/09/2017'),
(684, '05/09/2017'),
(685, '05/09/2017'),
(686, '05/09/2017'),
(687, '05/09/2017'),
(688, '05/09/2017'),
(689, '05/09/2017'),
(690, '05/09/2017'),
(691, '05/09/2017'),
(692, '05/09/2017'),
(693, '05/09/2017'),
(694, '05/09/2017'),
(695, '05/09/2017'),
(696, '05/09/2017'),
(697, '05/09/2017'),
(698, '05/09/2017'),
(699, '05/09/2017'),
(700, '05/09/2017'),
(701, '05/09/2017'),
(702, '05/09/2017'),
(703, '05/09/2017'),
(704, '05/09/2017'),
(705, '05/09/2017'),
(706, '05/09/2017'),
(707, '05/09/2017'),
(708, '06/09/2017'),
(709, '06/09/2017'),
(710, '06/09/2017'),
(711, '06/09/2017'),
(712, '06/09/2017'),
(713, '06/09/2017'),
(714, '06/09/2017'),
(715, '06/09/2017'),
(716, '06/09/2017'),
(717, '06/09/2017'),
(718, '06/09/2017'),
(719, '06/09/2017'),
(720, '06/09/2017'),
(721, '06/09/2017'),
(722, '06/09/2017'),
(723, '06/09/2017'),
(724, '06/09/2017'),
(725, '06/09/2017'),
(726, '06/09/2017'),
(727, '06/09/2017'),
(728, '06/09/2017'),
(729, '06/09/2017'),
(730, '06/09/2017'),
(731, '06/09/2017'),
(732, '06/09/2017'),
(733, '06/09/2017'),
(734, '06/09/2017'),
(735, '06/09/2017'),
(736, '06/09/2017'),
(737, '06/09/2017'),
(738, '06/09/2017'),
(739, '06/09/2017'),
(740, '06/09/2017'),
(741, '06/09/2017'),
(742, '06/09/2017'),
(743, '06/09/2017'),
(744, '06/09/2017'),
(745, '06/09/2017'),
(746, '06/09/2017'),
(747, '06/09/2017'),
(748, '06/09/2017'),
(749, '06/09/2017'),
(750, '06/09/2017'),
(751, '06/09/2017'),
(752, '06/09/2017'),
(753, '06/09/2017'),
(754, '06/09/2017'),
(755, '06/09/2017'),
(756, '06/09/2017'),
(757, '07/09/2017'),
(758, '07/09/2017'),
(759, '07/09/2017'),
(760, '07/09/2017'),
(761, '07/09/2017'),
(762, '07/09/2017'),
(763, '07/09/2017'),
(764, '07/09/2017'),
(765, '07/09/2017'),
(766, '07/09/2017'),
(767, '07/09/2017'),
(768, '07/09/2017'),
(769, '07/09/2017'),
(770, '07/09/2017'),
(771, '07/09/2017'),
(772, '07/09/2017'),
(773, '07/09/2017'),
(774, '07/09/2017'),
(775, '07/09/2017'),
(776, '07/09/2017'),
(777, '07/09/2017'),
(778, '07/09/2017'),
(779, '07/09/2017'),
(780, '07/09/2017'),
(781, '07/09/2017'),
(782, '07/09/2017'),
(783, '07/09/2017'),
(784, '07/09/2017'),
(785, '07/09/2017'),
(786, '07/09/2017'),
(787, '07/09/2017'),
(788, '07/09/2017'),
(789, '07/09/2017'),
(790, '07/09/2017'),
(791, '07/09/2017'),
(792, '07/09/2017'),
(793, '07/09/2017'),
(794, '07/09/2017'),
(795, '07/09/2017'),
(796, '08/09/2017'),
(797, '08/09/2017'),
(798, '08/09/2017'),
(799, '08/09/2017'),
(800, '08/09/2017'),
(801, '08/09/2017'),
(802, '08/09/2017'),
(803, '08/09/2017'),
(804, '09/09/2017'),
(805, '09/09/2017'),
(806, '09/09/2017'),
(807, '09/09/2017'),
(808, '09/09/2017'),
(809, '09/09/2017'),
(810, '09/09/2017'),
(811, '11/09/2017'),
(812, '11/09/2017'),
(813, '15/09/2017'),
(814, '15/09/2017'),
(815, '30/09/2017'),
(816, '04/10/2017'),
(817, '04/10/2017'),
(818, '04/10/2017'),
(819, '04/10/2017'),
(820, '06/10/2017'),
(821, '06/10/2017'),
(822, '09/10/2017'),
(823, '09/10/2017'),
(824, '10/10/2017');

-- --------------------------------------------------------

--
-- Table structure for table `workers`
--

CREATE TABLE IF NOT EXISTS `workers` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `fname` varchar(255) NOT NULL,
  `lname` varchar(555) NOT NULL,
  `gender` varchar(255) NOT NULL,
  `distr` varchar(255) NOT NULL,
  `parish` varchar(255) NOT NULL,
  `lochurch` varchar(255) DEFAULT NULL,
  `post` varchar(255) NOT NULL,
  `tel` text NOT NULL,
  `email` text,
  `user` text NOT NULL,
  `pass` text NOT NULL,
  `photo` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `workers`
--

INSERT INTO `workers` (`id`, `fname`, `lname`, `gender`, `distr`, `parish`, `lochurch`, `post`, `tel`, `email`, `user`, `pass`, `photo`) VALUES
(3, 'niyigira                  ', 'salomon                  ', '', 'Ruhango                  ', 'kagarama                  ', ' kagarama     ', 'acountant                  ', '0782396251                  ', 'niysalomon@gmail.com      ', 'niyo      ', 'salo      ', '12.jpg '),
(4, 'Habimana', 'innocent', '', 'Huye', 'kagarama', 'fdgfg', 'acountant', '0782396251', 'dsfdfd@gamil.com', 'simo', 'nsanzi', '2015-12-03_20.29.35.jpg'),
(5, 'Habineza     ', 'Christian     ', '', 'Nyamagabe     ', 'kagarama     ', 'kinihira1   ', 'pastor     ', '2222222222     ', 'niysalomon@gmail.com    ', 'kalou    ', 'king   ', 'CameraZOOM-20160727132557345.jpg '),
(6, 'masengesh   ', 'king   ', '', 'Rutare   ', 'Nyamasheke   ', 'kagarama   ', 'umutera   ', '0786626534   ', 'dsfdfd@gamil.com   ', 'skalou   ', 'salo   ', 'CameraZOOM-20170109082819436.jpg'),
(7, 'kamana ', 'fabrice ', 'Male', 'Byumba ', 'Rugandu ', 'kinihira ', 'pastor ', '0782396251 ', 'niysalomon@gmail.com ', 'simo ', 'nsanzi ', 'Aimbl Mik 20160306_183842.jpg ');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `localchurch`
--
ALTER TABLE `localchurch`
  ADD CONSTRAINT `localchurch_ibfk_1` FOREIGN KEY (`pid`) REFERENCES `parishs` (`pid`);

--
-- Constraints for table `parishs`
--
ALTER TABLE `parishs`
  ADD CONSTRAINT `parishs_ibfk_1` FOREIGN KEY (`Did`) REFERENCES `districts` (`Did`);

--
-- Constraints for table `reports`
--
ALTER TABLE `reports`
  ADD CONSTRAINT `reports_ibfk_1` FOREIGN KEY (`id`) REFERENCES `workers` (`id`);
